
(function ($) {
    "use strict";
    console.log('custom.js başladı');
    // Sayfa tamamen yüklendikten sonra çalıştırılacak kodlar
    $(document).ready(function() {
        // Owl Carousel
        $('.owl-show-events').owlCarousel({
            items: 4,
            loop: true,
            dots: true,
            nav: true,
            autoplay: true,
            margin: 30,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 4
                }
            }
        });

        // Eğer ana sayfadaysak sayaç başlasın
        if ($('body').hasClass('main')) {
            const second = 1000,
                minute = second * 60,
                hour = minute * 60,
                day = hour * 24;

            let countDown = new Date(Date.UTC(2025, 4, 11, 10, 30, 0)).getTime();

            let x = setInterval(function() {
                let now = new Date().getTime(),
                    distance = countDown - now;

                if (distance > 0) {
                    document.getElementById('days').innerText = Math.floor(distance / day);
                    document.getElementById('hours').innerText = Math.floor((distance % day) / hour);
                    document.getElementById('minutes').innerText = Math.floor((distance % hour) / minute);
                    document.getElementById('seconds').innerText = Math.floor((distance % minute) / second);
                } else {
                    clearInterval(x);
                    document.getElementById('days').innerText = '0';
                    document.getElementById('hours').innerText = '0';
                    document.getElementById('minutes').innerText = '0';
                    document.getElementById('seconds').innerText = '0';
                    console.log("Hedef tarih geçti!");
                }
            }, second);
        }

        // Menü açma/kapama
        if($('.menu-trigger').length){
            $(".menu-trigger").on('click', function() {
                $(this).toggleClass('active');
                $('.header-area .nav').slideToggle(200);
            });
        }

        // Sayfa yüklendikten sonra animasyonları başlat
        window.sr = new scrollReveal();

        // Menü dropdown işlevi (Mobil için)
        mobileNav();

        // Pencere yeniden boyutlandırıldığında menüyü kontrol et
        $(window).on('resize', function() {
            mobileNav();
        });

        // Mobil menü düzenlemesi
        function mobileNav() {
            var width = $(window).width();
            $('.submenu').on('click', function() {
                if(width < 767) {
                    $('.submenu ul').removeClass('active');
                    $(this).find('ul').toggleClass('active');
                }
            });
        }
        
    });

    // Sayfa tamamen yüklendiğinde preloader'ı gizle
    $(window).on('load', function () {
        console.log('Window fully loaded!');
        $('#js-preloader').fadeOut(500);
    });

})(window.jQuery);
