document.addEventListener('DOMContentLoaded', function () {  
  // DROPDOWN MENU
  const dropdownContainer = document.querySelector('.dropdown-container');
  const toggleButton = document.getElementById('userDropdownToggle');
  const dropdownMenu = document.getElementById('userDropdownMenu');

  if (toggleButton && dropdownMenu) {
    toggleButton.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdownContainer.classList.toggle('show');
    });

    document.addEventListener('click', function (e) {
      if (!dropdownContainer.contains(e.target)) {
        dropdownContainer.classList.remove('show');
      }
    });

    dropdownMenu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') {
        dropdownContainer.classList.remove('show');
      }
    });}
});
