document.addEventListener('DOMContentLoaded', function () {


  // Silme işlemleri
  const showAlertBtn = document.getElementById("showAlert");
  const alertBox = document.getElementById("alertBox");
  const deleteAccountBtn = document.getElementById("deleteAccountBtn");

  if (showAlertBtn && alertBox) {
    showAlertBtn.addEventListener("click", function (e) {
      e.preventDefault();
      alertBox.style.display = alertBox.style.display === "block" ? "none" : "block";
    });
  }

  if (deleteAccountBtn) {
    deleteAccountBtn.addEventListener("click", function () {
      if (confirm("Hesabınızı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz!")) {
        alert("Hesabınız başarıyla silindi!");
      } else {
        alert("İşlem iptal edildi.");
      }
    });
  }
});

document.addEventListener('DOMContentLoaded', function () {
    const yorumButonu = document.querySelector('[data-bs-target="#yorumYapModal"]');
    const yorumModalElement = document.getElementById('yorumYapModal');

    if (yorumButonu && yorumModalElement) {
        const yorumModal = new bootstrap.Modal(yorumModalElement);

        yorumButonu.addEventListener('click', function () {
            yorumModal.show();
        });

        const kapatButonu = yorumModalElement.querySelector('.btn[data-bs-dismiss="modal"]');
        if (kapatButonu) {
            kapatButonu.addEventListener('click', function () {
                yorumModal.hide();
            });
        }
    }
});