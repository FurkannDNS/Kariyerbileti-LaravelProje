document.addEventListener("DOMContentLoaded", function () {
    const cardHolderEl = document.getElementById('card-holder');
    const cardExpiryEl = document.getElementById('card-expiry');
    const cardCvvEl = document.getElementById('card-cvv');
    const cardLogoEl = document.getElementById('card-logo');

    const digitSpans = [];
    for (let i = 0; i < 16; i++) {
        digitSpans.push(document.getElementById(`card-digit-${i}`));
    }

    // Kart Sahibi
    document.getElementById('input-name').addEventListener('input', function () {
        cardHolderEl.textContent = this.value.trim() || 'Ad Soyad';
    });

    // Son Kullanma Tarihi
    document.getElementById('input-expiry').addEventListener('input', function () {
        let value = this.value.replace(/\D/g, '').slice(0, 4);
        if (value.length > 2) value = value.slice(0, 2) + '/' + value.slice(2);
        this.value = value;
        cardExpiryEl.textContent = value || 'Ay/Yıl';
    });

    // CVV
    document.getElementById('input-cvv').addEventListener('input', function () {
        const cvv = this.value.replace(/\D/g, '').slice(0, 3);
        this.value = cvv;
        cardCvvEl.textContent = cvv || '000';
    });

    // Kart Numarası
    document.getElementById('input-card-number').addEventListener('input', function () {
        let digits = this.value.replace(/\D/g, '').slice(0, 16);
        
        // Otomatik boşluk ekle
        let formatted = '';
        for (let i = 0; i < digits.length; i++) {
            if (i > 0 && i % 4 === 0) formatted += ' ';
            formatted += digits[i];
        }
        this.value = formatted;

        // Kart üstünde numarayı göster
        const displayDigits = digits.padEnd(16, '•');
        displayDigits.split('').forEach((digit, i) => {
            digitSpans[i].textContent = digit;
        });

        // Kart logosunu belirle
        const visaPattern = /^4/;
        const masterPattern = /^5[1-5]/;

        if (visaPattern.test(digits)) {
            cardLogoEl.src = 'assets/images/Visa.svg';
        } else if (masterPattern.test(digits)) {
            cardLogoEl.src = 'assets/images/Mastercard-logo.svg';
        } else {
            cardLogoEl.src = 'assets/images/Visa.svg'; // default
        }
    });


    //KARiYER PARA SEÇİM JS
    document.querySelectorAll('input[name="siteMoney"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('secilen-tutar').value = this.value;
    });
    });
    

})
