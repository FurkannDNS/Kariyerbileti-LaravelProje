<?php

namespace App\Notifications;

use Illuminate\Auth\Notifications\ResetPassword as BaseResetPassword;
use Illuminate\Notifications\Messages\MailMessage;

class ResetPasswordNotification extends BaseResetPassword
{
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Şifreni Sıfırlama Talebi | KariyerBİleti')
            ->greeting('Merhaba!')
            ->line('Şifreni sıfırlamak için aşağıdaki butona tıklayabilirsin.')
            ->action('Şifremi Sıfırla', url(config('app.url') . route('password.reset', ['token' => $this->token, 'email' => $notifiable->getEmailForPasswordReset()], false)))
            ->line('Eğer bu işlemi sen yapmadıysan, bu maili görmezden gelebilirsin.')
            ->salutation('Sevgiler, KariyerBİleti Ekibi');
    }
}
