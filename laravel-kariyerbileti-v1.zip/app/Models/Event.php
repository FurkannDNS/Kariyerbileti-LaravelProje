<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Event extends Model
{   
    use SoftDeletes; // Soft delete özelliğini kullanıyoruz
    protected $fillable = [
        'id',
        'title',
        'description',
        'image_path',
        'event_date',
        'location',
        'etkinlik_tipi',
        'etkinlik_turu',
        'bilet_fiyati',
        'etkinlik_kodu',
        'created_at',
        'updated_at',
        'deleted_at', // Soft delete için ekliyoruz
    ];
    
    protected $table = 'events'; // tablonun ismini belirtiyoruz
    public function yorumlar()
    {
        return $this->hasMany(EtkinlikYorum::class, 'etkinlik_kodu', 'etkinlik_kodu')
                    ->where('status', 'onaylı');
    }

    
}

/*
3. Silme işlemini güncelle
**Artık admin Event::find($id)->delete(); dediğinde kayıt tamamen gitmez, 
sadece deleted_at sütunu dolar.

4. Aktif etkinlikleri çek
Varsayılan Laravel sorguları deleted_at dolu kayıtları göstermez.

Ama illa görmek istersen:
**$events = Event::withTrashed()->get();  // Silinmiş ve silinmemiş tüm etkinlikler

ya da sadece silinmişler:
$events = Event::onlyTrashed()->get();

5. Blade tarafında null kontrolüne gerek kalmaz
Çünkü etkinlik hala var, ilişkiler kopmaz.

6. Admin panelinde “silinen etkinlikleri göster ve geri yükle”
özelliği ekleyebilirsin (opsiyonel)
Örnek:

**Geri yükleme
Event::withTrashed()->find($id)->restore();

Admin silmek istediğinde aslında “pasif” yapıyor gibi düşünebilirsin,
ama veritabanı arka planda bu işi otomatik hallediyor.*/