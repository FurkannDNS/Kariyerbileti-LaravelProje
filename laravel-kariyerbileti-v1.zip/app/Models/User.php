<?php

namespace App\Models;
use App\Models\Ticket;
use App\Notifications\ResetPasswordNotification;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;
    

    protected $table = 'users'; // zaten bu isimde, istersen kaldırabilirsin

    protected $primaryKey = 'id';

    public $timestamps = true;

    protected $fillable = [
        'ad',
        'soyad',
        'email',
        'telefon',
        'role',
        'dogum_tarihi',
        'password',
        'created_at',
        'updated_at',
        'bakiye',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
    protected $casts = [
    'dogum_tarihi' => 'datetime',
    ];
    public function tickets()
    {
        return $this->hasMany(Ticket::class);
        //Auth::user()->tickets BU fonksiyon sonucu olarak return ile kullanıcı- bilet tablosunu bağlayıp verileri kolayca çekebilirz

    }

    public function destek()
    {
        return $this->hasMany(SupportUser::class,'kullanici_id');
        //Auth::user()->tickets BU fonksiyon sonucu olarak return ile kullanıcı- bilet tablosunu bağlayıp verileri kolayca çekebilirz

    }
    

    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }



}
