<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class YorumOyKontrol extends Model
{
    protected $table = 'yorum_oy_kontrol';

    protected $fillable = ['user_id', 'etkinlik_yorum_id', 'tur'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function yorum()
    {
        return $this->belongsTo(EtkinlikYorum::class, 'etkinlik_yorum_id');
    }
}
