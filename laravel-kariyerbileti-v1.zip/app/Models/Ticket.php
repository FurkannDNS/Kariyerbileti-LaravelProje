<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;
    protected $table = 'tickets';

    protected $fillable = [
        'user_id',
        'etkinlik_kodu',
        'status',
        'purchase_date',
        'bilet_kodu',
    ];

    protected $dates = ['purchase_date'];
    protected $casts = [
    'purchase_date' => 'datetime',
    ];

    // Status sabitleri
    const STATUS_VALID = 'valid';
    const STATUS_USED = 'used';
    const STATUS_CANCELLED = 'cancelled';

    // Kullanıcı ilişkisi (her bilet bir kullanıcıya aittir)
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    //Bilet tablosu  İlişkisi
    public function event()
    {
        return $this->belongsTo(Event::class, 'etkinlik_kodu', 'etkinlik_kodu');    
    }

}
