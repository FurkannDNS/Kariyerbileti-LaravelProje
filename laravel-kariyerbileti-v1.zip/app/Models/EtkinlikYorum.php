<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EtkinlikYorum extends Model
{
    protected $table="etkinlik_yorumlari";
    protected $fillable = [
        'id',
        'kullanici_id',
        'etkinlik_kodu',
        'yorum_metni',
        'status',
        'like_sayisi',
        'dislike_sayisi',
    ];
    
    public function user()
    {
        return $this->belongsTo(User::class, 'kullanici_id');
    }

    
    public function event()
    {
        return $this->belongsTo(Event::class, 'etkinlik_kodu', 'etkinlik_kodu', 'title');    
    }
}
