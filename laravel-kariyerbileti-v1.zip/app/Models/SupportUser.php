<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SupportUser extends Model
{
    // app/Models/SupportTicket.php

    protected $table = 'support_user';

    protected $fillable = [
        'kullanici_id',
        'etkinlik_kodu',
        'kategori',
        'destek_metni',
        'cevap_metni',
        'status',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'kullanici_id');
    }
    
    
}


