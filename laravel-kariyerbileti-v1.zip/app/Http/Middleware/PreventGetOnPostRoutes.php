<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class PreventGetOnPostRoutes
{
    public function handle(Request $request, Closure $next)
    {
        if (
            $request->is('login') &&
            $request->method() === 'GET'
        ) {
            return redirect()->route('oturum-ac')
                ->with('error', 'Lütfen önce giriş yapın.');
        }

        return $next($request);
    }
}
