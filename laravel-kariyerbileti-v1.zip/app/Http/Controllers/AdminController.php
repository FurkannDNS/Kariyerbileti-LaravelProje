<?php

namespace App\Http\Controllers;

use App\Models\SupportUser;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Ticket;
use App\Models\Event;
use App\Models\SupportTicket;
use Exception;
use Illuminate\Support\Facades\Storage; 

class AdminController
{
   

public function userView()
{
    $kullanicilar = User::all(); // Tüm kullanıcıları al
    return view('admin.kullanici_yonetim', compact('kullanicilar')); // Blade dosyana gönder
}
public function edit($id)
{
    $kullanici = User::findOrFail($id);
    return view('admin.kullanici_duzenle', compact('kullanici'));
}

public function userUpdate(Request $request, $id)
{
    try {
        $kullanici = User::findOrFail($id);

        $kullanici->update([
            'ad' => $request->input('ad'),
            'spyad' => $request->input('soyad'),
            'dogum_tarihi' => $request->input('dogum_tarihi'),
            'email' => $request->input('email'),
            'role' => $request->input('role'),
            'telefon' => $request->input('telefon'),
        ]);

        return redirect()->back()->with(
            'success',
             'Geçerli Kullanıcının Bilgileri Başarıyla Güncellendi.'
        );
    } catch (Exception $e) {
        return redirect()->back()->with(
            'error',
            'Güncelleme Sırasında Bir Hata Oluştu: ' . $e->getMessage()
        );
    }
}

public function userDelete(Request $request, $id)
{
    $kullanici = User::findOrFail($id);
    $kullanici->delete(); // Kullanıcıyı sil
    return redirect()->back()->with('success', 'Kullanıcı başarıyla silindi.');
}




public function ticketUsed(Request $request, $id)
{
    
    $bilet = Ticket::findOrFail($id);
    $bilet->status = 'used'; // Status alanını güncelliyoruz
    $bilet->save();

    return redirect()->back()->with('success', 'Bilet başarıyla kullanıldı.');
}

public function ticketDelete($id)
{
    $bilet = Ticket::findOrFail($id);
    $bilet->delete(); // Bileti sil
    return redirect()->back()->with('success', 'Bilet başarıyla silindi.');
}

public function ticketView()
{
    $biletler = Ticket::all(); // Tüm biletleri al
    return view('admin.bilet_yonetim', compact('biletler')); // Blade dosyana gönder
    // Biletlerin etkinlik bilgilerini de yükle
}

public function usedYap()
{   
    $bugun = date('Y-m-d');

    // Etkinlik tarihi geçmiş ama hâlâ valid olan biletler
    $etkinlikKodlari = Event::where('event_date', '<', $bugun)->pluck('etkinlik_kodu');

    $etkilenen = Ticket::whereIn('etkinlik_kodu', $etkinlikKodlari)
        ->where('status', 'valid')
        ->update(['status' => 'used']);

    return redirect()->back()->with('success', "$etkilenen bilet kullanıldı olarak işaretlendi.");
}




public function showTicketPdf($bilet_kodu)
{
    $filePath = storage_path("app/public/assets/biletler/bilet_{$bilet_kodu}.pdf");

    if (!file_exists($filePath)) {
        abort(404, 'Bilet PDF dosyası bulunamadı.');
    }

    return response()->file($filePath, [
        'Content-Type' => 'application/pdf',
    ]);
}


public function etkinlikView()
{
    $etkinlikler = Event::all(); // Tüm etkinlikleri al
    return view('admin.etkinlik_yonetim', compact('etkinlikler')); // Blade dosyana gönder
}

public function addEvent(Request $request)
{
    // Formdan gelen verileri al
    $eventId = $request->input('title');
    $eventDescription = $request->input('description');
    $eventImage = $request->file('image'); // Resim dosyasını al
    $eventImagePath = null;

    if ($eventImage) {
        // storage/app/public/assets/etkinlik_foto altına kaydet
        ;
        $filename =  $eventImage->getClientOriginalName();
        // Dosya adını benzersiz yapmak için zaman damgası ekliyoruz
        // Dosyayı public diskine kaydet
        // Bu, storage/app/public/assets/etkinlik_foto/... şeklinde kaydeder
        $eventImagePath = $eventImage->storeAs('assets/etkinlik_foto', $filename, 'public');
       ;
        // Bu yol, public/storage/assets/etkinlik_foto/... şeklinde web'de erişilebilir
    }

    $eventDate = $request->input('event_date');
    $eventLocation = $request->input('location');
    $etkinlikTipi = $request->input('etkinlik_tipi');
    $etkinlikTuru = $request->input('etkinlik_turu');
    $biletFiyati = $request->input('bilet_fiyati');
    $etkinlikKodu = $request->input('etkinlik_kodu');

    // Veritabanına kaydet
    Event::create([
        'title' => $eventId,
        'description' => $eventDescription,
        'image_path' => $eventImagePath ?? null, // Örn: assets/etkinlik_foto/resim.jpg
        'event_date' => $eventDate,
        'location' => $eventLocation,
        'etkinlik_tipi' => $etkinlikTipi,
        'etkinlik_turu' => $etkinlikTuru,
        'bilet_fiyati' => $biletFiyati,
        'etkinlik_kodu' => $etkinlikKodu,
    ]);

    return redirect()->back()->with('success', 'Etkinlik başarıyla eklendi.');
}
public function deleteEvent($id)
{
    $event = Event::findOrFail($id);

    if ($event->image_path && Storage::disk('public')->exists($event->image_path)) {
        Storage::disk('public')->delete($event->image_path);
    }

    $event->delete();

    return redirect()->back()->with('success', 'Etkinlik ve görsel başarıyla silindi.');
}

public function editEventshow($id)
{
    $editedEvent = Event::findOrFail($id);

    return view('admin.etkinlik_duzenle', compact('editedEvent'));
}
public function editEventStore(Request $request, $id)
{
    $event = Event::findOrFail($id);

    $event->title = $request->input('title');
    $event->description = $request->input('description');
    $event->event_date = $request->input('event_date');
    $event->location = $request->input('location');
    $event->etkinlik_tipi = $request->input('etkinlik_tipi');
    $event->etkinlik_turu = $request->input('etkinlik_turu');
    $event->bilet_fiyati = $request->input('bilet_fiyati');
    $event->etkinlik_kodu = $request->input('etkinlik_kodu');

    if ($request->hasFile('image')) {
        // Eski görseli sil
        if ($event->image_path && \Storage::disk('public')->exists($event->image_path)) {
            \Storage::disk('public')->delete($event->image_path);
        }
        $image = $request->file('image');
        $filename = $image->getClientOriginalName();
        $imagePath = $image->storeAs('assets/etkinlik_foto', $filename, 'public');
        $event->image_path = $imagePath;
    }

    $event->save();

    return redirect()->route('admin.etkinlikler')->with('success', 'Etkinlik başarıyla güncellendi.');
}


}