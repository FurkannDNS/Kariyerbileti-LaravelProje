<?php

namespace App\Http\Controllers;

use App\Models\SupportUser;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class SupportTicketController extends Controller
{
    public function destekindex()
    {
        // Destek işlemleri için gerekli verileri al
        $talepler= SupportUser::with('user')->get(); // Tüm destek taleplerini al
        // Örneğin, destek taleplerini veya yorumları alabilirsiniz
        return view('admin.destek',compact('talepler')); // Destek yönetim sayfasını döndür
    }


    public function store(Request $request)
    {
        

        $request->validate([
            'kategori' => 'required|string|max:255',
            'destek_metni' => 'required|string',
            'etkinlik_kodu' => 'required|string|max:255',
        ]);

        SupportUser::create([
            'kullanici_id' => Auth::id(),
            'etkinlik_kodu' => $request->etkinlik_kodu,
            'kategori' => $request->kategori,
            'destek_metni' => $request->destek_metni,
            'status' => 'beklemede',
        ]);

        return redirect()->route('user.panel')->with('success', 'Destek talebin başarıyla oluşturuldu!');
    }

    public function cevapla(Request $request, $id)
    {
        
        $request->validate([
            'cevap_metni' => 'required|string',
        ]);

        $talep = SupportUser::findOrFail($id);
        $talep->cevap_metni = $request->cevap_metni;
        $talep->status = 'kapali'; // İstersen burada otomatik kapatabilirsin
        $talep->save();

        return redirect()->back()->with('success', 'Destek talebine cevap gönderildi.');
    }

    public function delete($id)
    {
        $talep = SupportUser::findOrFail($id);
        $talep->delete();

        return redirect()->back()->with('success', 'Destek talebi başarıyla silindi.');
    }
}
