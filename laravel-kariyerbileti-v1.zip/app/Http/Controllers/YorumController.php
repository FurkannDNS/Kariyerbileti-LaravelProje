<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Routing\Controller;
use App\Models\EtkinlikYorum;
use App\Models\YorumOyKontrol;
use Illuminate\Support\Facades\Auth;

use Exception;

class YorumController extends Controller
{

    public function oyla(Request $request)
    {
        $userId = Auth::user()->id;
        
        if (!$userId) {
            return response()->json(['error' => 'Kullanıcı giriş yapmamış!'], 401);
        }

        $yorumId = $request->input('yorum_id');
        $oyTuru = $request->input('oy_turu');

        if (!$yorumId || !$oyTuru) {
            return response()->json(['error' => 'yorum_id ve oy_turu zorunlu!'], 422);
        }

        $yorum = EtkinlikYorum::find($yorumId);
        if (!$yorum) {
            return response()->json(['error' => 'Yorum bulunamadı!'], 404);
        }

        $oncekiOy = YorumOyKontrol::where('etkinlik_yorum_id', $yorumId)
                                ->where('user_id', $userId)
                                ->first();

        if ($oncekiOy) {
            if ($oncekiOy->tur == $oyTuru) {
                // aynı oy tekrar gelirse, oy geri çekiliyor
                if ($oyTuru == 'like') {
                    $yorum->decrement('like_sayisi');
                } else {
                    $yorum->decrement('dislike_sayisi');
                }

                $oncekiOy->delete();

                return response()->json([
                    'message' => 'Oyunuz geri alındı.',
                    'type' => 'warning',
                    'yeni_sayi' => $oyTuru == 'like' ? $yorum->like_sayisi : $yorum->dislike_sayisi
                ], 200);
            } else {
                // farklı oy veriliyorsa önce eski oyu kaldır, sonra yeni oy ekle
                if ($oncekiOy->tur == 'like') {
                    $yorum->decrement('like_sayisi');
                } else {
                    $yorum->decrement('dislike_sayisi');
                }

                if ($oyTuru == 'like') {
                    $yorum->increment('like_sayisi');
                } else {
                    $yorum->increment('dislike_sayisi');
                }

                $oncekiOy->tur = $oyTuru;
                $oncekiOy->save();

                $yorum->save();

                return response()->json([
                    'message' => 'Oyunuz güncellendi.',
                    'type' => 'success',
                    'like_sayisi' => $yorum->like_sayisi,
                    'dislike_sayisi' => $yorum->dislike_sayisi
                ], 200);
            }
        } else {
            // hiç oy yoksa yeni oy ekle
            YorumOyKontrol::create([
                'etkinlik_yorum_id' => $yorumId,
                'user_id' => $userId,
                'tur' => $oyTuru,
            ]);

            if ($oyTuru == 'like') {
                $yorum->increment('like_sayisi');
            } else {
                $yorum->increment('dislike_sayisi');
            }

            $yorum->save();

            return response()->json([
                'message' => 'Oy verildi!',
                'type' => 'success',
                'yeni_sayi' => $oyTuru == 'like' ? $yorum->like_sayisi : $yorum->dislike_sayisi
            ], 201);
        }
    }



        

    // Yorumları admin tarafında listele
    public function index()
    {
        $yorums = EtkinlikYorum::with(['user','event'])->get();
        return view('admin.yorumlar', compact('yorums'));
    }

    // Yorum oluştur
    public function store(Request $request)

    {
        
        $request->validate([
            'etkinlik_kodu' => 'required|exists:tickets,etkinlik_kodu',
            'yorum_metni' => 'required|string|min:3',
        ]);

        EtkinlikYorum::create([
            'kullanici_id' => Auth::id(),
            'etkinlik_kodu' => $request->etkinlik_kodu,
            'yorum_metni' => $request->yorum_metni,
            'status' => 'beklemede', // default olarak admin onayı gerekebilir
        ]);

        return back()->with('success', 'Yorum gönderildi. Onay bekliyor.');
    }





    // Yorum sil
    public function delete($id)
    {
        try {
            $yorum = EtkinlikYorum::findOrFail($id);
            $yorum->delete();
            // Eğer yorumun silinmesi yerine sadece durumunu güncellemek isterseniz:

            return back()->with('success', 'Yorum başarıyla reddedildi ve silindi.');
        } catch (Exception $e) {
            return back()->with('error', 'Yorum bulunamadı.');
        }

    }

    public function onayla($id)
    {   
        try {
            $yorum = EtkinlikYorum::findOrFail($id,'id');
            
            $yorum->status = 'onaylı'; // veya istediğiniz başka bir durum
            $yorum->save();

            return back()->with('success', 'Yorum onaylandı.');
        } catch (Exception $e) {
            return back()->with('error', 'Yorum bulunamadı.');
        }

    }
}
