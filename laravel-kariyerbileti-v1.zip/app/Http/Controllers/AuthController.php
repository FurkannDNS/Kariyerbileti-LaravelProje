<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        // 1. Giriş bilgilerini doğrula
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        // 2. Bilgiler doğruysa giriş yap
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            // Kullanıcıyı biletleriyle birlikte yükle, istersen kullan
            //$user = Auth::user()->load('tickets.events');

            // Doğrudan dashboard'a yönlendir, middleware yönlendirecek
            return redirect()->route('user.panel');
        }

        // 5. Giriş başarısızsa uyarı ver
        return back()->withErrors([
            'email' => 'Girdiğiniz bilgiler hatalı.Mail',
        ])->withInput($request->only('email'));
    }
    public function logout(Request $request)
    {
        
        Auth::logout();
        session()->flush();  // Oturum verilerini temizler
        

        // Tüm oturum verilerini temizle
        
       

        return redirect()->route('oturum-ac'); // login rotan neyse oraya yönlendir
    }
    

}