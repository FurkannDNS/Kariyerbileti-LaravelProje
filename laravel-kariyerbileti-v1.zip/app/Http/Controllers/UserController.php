<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    

    public function store(Request $request)
    {
        // ✅ Doğrulama
        $request->validate([
            'ad' => 'required|string|max:50',
            'soyad' => 'required|string|max:50',
            'email' => 'required|email|unique:users,email',
            'telefon' => 'nullable|string|max:15',
            'role' => 'required|in:admin,standart',
            'dogum_tarihi' => 'required|date',
            'password' => 'required|string|min:8',
            
        ],
        [
            'email.unique' => 'Bu e-posta adresi zaten kaydedilmiş, lütfen başka bir e-posta adresi kullanın ya da giriş yapın.'
        ]);
    
        DB::beginTransaction(); // Veritabanı işlemini başlat
    
        try {
            // ✅ Kayıt
            $user = User::create([
                
                'ad' => $request->ad,
                'soyad' => $request->soyad,
                'email' => $request->email,
                'telefon' => $request->telefon,
                'role' => $request->role,
                'dogum_tarihi' => $request->dogum_tarihi,
                'password' => bcrypt($request->password),
                'kayit_tarihi' => now(),
                'bakiye'=>0.00,
            ]);
            
            DB::commit(); // İşlem başarılı, değişiklikleri kaydet
            
            // Sayfa yönlendirme veya success mesajı
           /*
            Alttaki kod şu anlama geliyormuş:

            redirect()->back(): Tarayıcıyı formun geldiği sayfaya geri gönder.

            with('success', '...'): Geri gönderirken session'a bir success mesajı ekle.
           */
            return redirect()->back()->with('success', 'Kayıt başarılı! Giriş Yapabilirsiniz');
    
           
        } catch (\Exception $e) {
            DB::rollBack(); // Bir hata oluşursa işlemi geri al
        
            return redirect()->back()->with('failure', 'Kayıt Başarısız! Bir Hata Oluştu. Lütfen Tekrar Deneyin'. $e->getMessage());
        }
        
    }

    /**
     * Update user information (telefon)
     */
    public function updateInfo(Request $request)
    {
        $user = Auth::user();

        $validator = Validator::make($request->all(), [
            'telefon' => 'nullable|string|max:11'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with([
                'success' => false,
                'message' => 'Geçersiz telefon numarası formatı'
            ]);
        }

        try {
            $user->update([
                'telefon' => $request->telefon
            ]);

            return redirect()->back()->with([
                'success' => true,
                'message' => 'Bilgileriniz başarıyla güncellendi'
            ]);

        } catch (\Exception $e) {
            Log::error('User info update error: '.$e->getMessage());

            return redirect()->back()->with([
                'success' => false,
                'message' => 'Bir hata oluştu, lütfen tekrar deneyin'
            ]);
        }
    }

    /**
     * Delete user account
     */
    public function deleteAccount(Request $request)
    {
        $user = Auth::user();
        // Önce biletleri sil(user tablosu ile ticket sayfasını 'USER' modelinde bağladık)
        $user->tickets()->delete(); 


        Auth::logout();
        $user->delete(); // forceDelete() de olabilir

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/')->with('status', 'Hesabınız başarıyla silindi.');
    }

        public function biletlerim(Request $request)
    {
        $user = Auth::user();
        // Önce biletleri sil(user tablosu ile ticket sayfasını 'USER' modelinde bağladık)
        $user->tickets();

        
    }

    
            
    
        
}
    



