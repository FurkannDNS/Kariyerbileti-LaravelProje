<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use App\Models\Ticket;
use Illuminate\Support\Facades\Auth;
use Pest\Collision\Events;
use Illuminate\Support\Str;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\File;
use function Laravel\Prompts\form;


class TicketController extends Controller
{


    public function index(Request $request)
    {
        $query = Event::query();

        // Etkinlik Yeri filtresi
        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        // Etkinlik Türü filtresi
        if ($request->filled('etkinlik_turu')) {
            $query->where('etkinlik_turu', $request->etkinlik_turu);
        }

        // Fiyat aralığı filtresi
        if ($request->filled('fiyat')) {
            $fiyatAralik = explode('-', $request->fiyat);
            if (count($fiyatAralik) === 2) {
                $query->whereBetween('bilet_fiyati', [(int)$fiyatAralik[0], (int)$fiyatAralik[1]]);
            }
        }

        // Tarih sıralama filtresi
        if ($request->filled('tarih') && in_array($request->tarih, ['asc', 'desc'])) {
            $query->orderBy('event_date', $request->tarih);
        } else {
            $query->orderBy('event_date', 'desc'); // Varsayılan: önce en yeni
        }

        // Etkinlikleri al ve 6'şar sayfalara böl
        $events = $query
            ->select('id', 'title', 'description', 'image_path', 'event_date', 'location', 'bilet_fiyati', 'etkinlik_kodu')
            ->paginate(6);

        // Bugünün tarihini al
        $bugun = date('Y-m-d');

        // Etkinliğin geçmişte mi olduğunu kontrol etme kısmı
        $events->getCollection()->transform(function ($event) use ($bugun) {
            $event->is_past = $event->event_date < $bugun;
            return $event;
        });

        // Mevcut lokasyonları al
        $locations = Event::pluck('location')->unique();

        return view('tickets', compact('events', 'locations'));
    }






    public function show($code)
    {
        // Etkinliği ve ilişkili yorumlarını eager load ile çekiyoruz
        $event = Event::with('yorumlar')->where('etkinlik_kodu', $code)->first();
    
        if (!$event) {
            return abort(404, 'Etkinlik bulunamadı');
        }
        
        //Code ile uygun olan biletin özelliklerini alarak sayfaya git ($event);
        return view('ticket-details', compact('event'));
    }
    
    
    public function addToCart($code)
    {
        $event = Event::where('etkinlik_kodu', $code)->firstOrFail();
        
    
        $cart = session()->get('cart', []);
    
        $cart[$event->id] = [
            "title" => $event->title,
            "quantity" => 1,
            "etkinlik_tipi" =>$event->etkinlik_tipi,
            "etkinlik_turu" =>$event->etkinlik_turu,
            "image_path"=>$event->image_path,
            "location"=>$event->location,
            "event_date"=> $event->event_date,
            "bilet_fiyati" => $event->bilet_fiyati,
            "total"=>0,


        ];
    
        session()->put('cart', $cart);
    
        return redirect()->back()->with('success', 'Etkinlik sepete eklendi!');
    }


    //Gizli Sepete Ekledigimiz verileri Sepette Gösterme
    public function showCart()
    {
        $cart = session()->get('cart', []);
        return view('sepet', compact('cart'));
    }

    
    //Gizli Sepete Ekledigimiz verileri Sepetten Silme
    public function remove(Request $request)
    {
        $cart = session()->get('cart', []);
        $id = $request->input('id');

        if (isset($cart[$id])) {
            unset($cart[$id]);
            session()->put('cart', $cart);
        }

        return redirect()->back()->with('success', 'Etkinlik sepetten kaldırıldı.');
    }


    //BAKİYE YUKLE
    public function bakiyeYukle(Request $request)
    {
        $request->validate([
            'siteMoney' => 'required|numeric|min:1',
        ]);

        $user = Auth::user();
        $eklenecekTutar = $request->input('siteMoney');

        try {
            $user->bakiye += $eklenecekTutar;
            $user->save();

            return redirect()->route('user.panel')->with('success', 'Bakiye başarıyla yüklendi!');

        } catch (Exception $e) {
            return redirect()->route('payment')->with('error', 'Bakiye yüklenemedi!');
        }
    }



    
    //BİLET SATIN ALIMI
    public function purchaseTicket(Request $request)
    {
        DB::beginTransaction();

        try {
            $user = Auth::user();
            $cart = session()->get('cart', []);

            if (empty($cart)) {
                return redirect()->back()->with('warning','Sepetiniz Boş!');
            }

            
            $toplamTutar = collect($cart)->sum(function($item) {
                return ($item['bilet_fiyati'] * $item['quantity'] * 1.18);
            });
            

            if ($user->bakiye < $toplamTutar) {
                \Log::info('Yetersiz bakiye kontrolü geçti. Kullanıcı Bakiye: ' . $user->bakiye . ' - Gerekli: ' . $toplamTutar);

                return redirect()->route('show-cart')->with('error', 'Yetersiz bakiye!');
            }

            $user->bakiye -= $toplamTutar;
            $user->save();

            foreach ($cart as $eventId => $item) {
                for ($i = 0; $i < $item['quantity']; $i++) {
                    $event = Event::find($eventId);
                    $biletKodu = 'KB' . $event->etkinlik_kodu . '-' . strtoupper(Str::random(8));
                    
                    Ticket::create([
                        'user_id' => $user->id,
                        'etkinlik_kodu' => $event->etkinlik_kodu,
                        'status' => 'valid',
                        'bilet_kodu' => $biletKodu,
                        'purchase_date' => now(),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    try {
                        $pdf = Pdf::loadView('pdf.kullanici-bilet', [
                            'etkinlik' => $event->etkinlik_kodu,
                            'etkinlik_baslik' => $event->title ?? 'Başlık Bulunamadı',
                            'katilimci' => $user->ad,
                            'bilet_kodu' => $biletKodu,
                            'etkinlik_tarihi' => $event->event_date,
                            'etkinlik_yeri' => $event->location,
                            'olusturmaZamani' => now()->format('d-m-Y H:i:s'),

                        ])
                        ->setPaper('A4', 'portrait')
                        ->setOptions([
                            'isHtml5ParserEnabled' => true,
                            'isRemoteEnabled' => true,
                            'defaultFont' => 'DejaVu Sans',
                        ]);

                        \Log::info("Bilet Kesim Tarihi: " . now()->format('d-m-Y H:i:s'));

                        $pdfPath = "assets/biletler";
                        $fullPath = storage_path("app/public/{$pdfPath}/bilet_{$biletKodu}.pdf");

                        if (!File::exists(storage_path("app/public/{$pdfPath}"))) {
                            File::makeDirectory(storage_path("app/public/{$pdfPath}"), 0755, true);
                        }

                        $pdf->save($fullPath);
                    } catch (Exception $e) {
                        \Log::error('PDF oluşturma/kaydetme hatası: ' . $e->getMessage());
                    }
                }
            }

            session()->forget('cart');
            DB::commit();

            return redirect()->back()->with(
                'success',
                'Bilet başarıyla satın alındı!'
            );

        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->back()->with(
                'error',
                'Bilet satın alma başarısız!'
            );
        }
    }
    

    //BİLETİMİ GÖSTER   
    public function biletlerim()
    {
        $user = Auth::user();

        $tickets = Ticket::with('event')
            ->where('user_id', $user->id)
            ->orderByDesc('purchase_date')
            ->take(5) // Son 5 bilet
            ->get();

        return view('user-dashboard', compact('tickets'));
    }


    //BİLET PDF GÖSTERME
    public function showPdf($bilet_kodu)
    {
        $ticket = Ticket::where('bilet_kodu', $bilet_kodu)->firstOrFail();
        $user = $ticket->user; // İlişki varsa user modelini alabilirsin
        $katilimci = $user->ad . ' ' . $user->soyad; // Kullanıcı adını ve soyadını birleştiriyoruz
        $pdf = Pdf::loadView('pdf.kullanici-bilet', [
            'etkinlik_baslik' => $ticket->event->title, // Etkinlik başlığını alıyoruz
            'etkinlik_kodu' => $ticket->etkinlik_kodu,
            'katilimci' => $katilimci, // Kullanıcı adını ve soyadını alıyoruz
            'etkinlik_tarihi' => $ticket->event->event_date, // Etkinlik tarihini formatlıyoruz
            'bilet_kodu' => $ticket->bilet_kodu,
            'olusturmaZamani' => $ticket->purchase_date,
            'etkinlik_yeri' => $ticket->event->location, // Etkinlik yerini alıyoruz
        ]);

        // Direkt yeni sekmede açmak için inline gösteriyoruz:
        return $pdf->stream('bilet_' . $ticket->bilet_kodu . '.pdf');
    }

}