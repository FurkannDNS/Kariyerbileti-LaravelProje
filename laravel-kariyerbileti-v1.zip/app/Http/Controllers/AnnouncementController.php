<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class AnnouncementController extends Controller
{



    public function addAnnouncement(Request $request)
    {
        $request->validate([
            'form_title' => 'required|max:255',
            'form_content' => 'required',
        ]);

        Announcement::create([
            'announcement_title' => $request->input('form_title'),
            'announcement_content' => $request->input('form_content'),
        ]);

        return redirect()->route('duyuru.index')->with('success', 'Duyuru eklendi!');
    }


    public function index()
    {
        $duyurular = Announcement::latest()->paginate(10);
        return view('admin.duyuru-olustur', compact('duyurular'));
    }

    public function deleteAnnouncement($id)
    {
        $duyurular = Announcement::findOrFail($id);
        $duyurular->delete();

        return redirect()->route('duyuru.index')->with('success', 'Duyuru silindi!');
    }
}
