<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

use App\Models\Announcement;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SupportTicketController;
use App\Http\Controllers\YorumController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Middleware\NoCacheHeaders;
use App\Http\Controllers\AnnouncementController;



// Genel erişime açık sayfalar
Route::middleware(['web',NoCacheHeaders::class])->group(function () {
    Route::get('/', function () {
    $announcements = Announcement::latest()->take(5)->get(); // Son 5 duyuruyu al
    return view('index', compact('announcements'));
    })->name('main');

    Route::view('/about-us', 'about-us')->name('about-us');
    Route::view('/kayit-ol', 'kayit-ol')->name('kayit-ol');
    Route::get('/tickets', [TicketController::class, 'index'])->name('tickets');
    Route::get('/tickets/{code}', [TicketController::class, 'show'])->name('ticket-details');
    Route::get('/sepet', [TicketController::class, 'showCart'])->name('show-cart');
    Route::get('/sepet/{code}', [TicketController::class, 'addToCart'])->name('ticket-add-cart');
    Route::view('/oturum-ac', 'oturum-ac')->name('oturum-ac');
    Route::view('/payment', 'payment')->name('payment');
    Route::get('/biletler/{bilet_kodu}/pdf', [TicketController::class, 'showPdf'])->name('ticket.pdf');
});

// Kayıt & Login işlemleri
Route::post('/store', [UserController::class, 'store'])->name('users.store');
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Sepet POST işlemleri
Route::post('/sepet-sil', [TicketController::class, 'remove'])->name('cart-remove');

// Şifre sıfırlama işlemleri
Route::get('/sifre-unuttum', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('/sifre-mail-gonder', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('/sifre-sifirla/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/sifre-sifirla', [ResetPasswordController::class, 'reset'])->name('password.update');

// Yorum işlemi
Route::post('/yorumlar', [YorumController::class, 'store'])->name('yorum.store');
Route::post('/yorum-oyla', [YorumController::class, 'oyla'])->middleware('auth')->name('yorum.oyla');

// Kullanıcı ve admin panelleri (auth + cache kapalı)
Route::middleware(['auth', NoCacheHeaders::class])->group(function () {
    // Ortak yönlendirme
    Route::get('/dashboard', fn () => redirect()->route('user.panel'));

    // Kullanıcı paneli
    Route::get('/user-dashboard', function () {
        $user = Auth::user()->load('destek'); // doğru ilişki "destekler"
        return view('user-dashboard', compact('user'));
    })->name('user.panel');

    // Bakiye yükleme
    Route::post('/payment', [TicketController::class, 'bakiyeYukle'])->name('bakiye.yukle');
    Route::post('/purchase-ticket', [TicketController::class, 'purchaseTicket'])->name('ticket.purchase');

    // Kullanıcı güncelle/sil
    Route::post('/user/update', [UserController::class, 'updateInfo'])->name('user.update');
    Route::post('/user/delete', [UserController::class, 'deleteAccount'])->name('user.delete');

    // Destek işlemleri
    Route::prefix('user-dashboard')->group(function () {
        Route::post('/support', [SupportTicketController::class, 'store'])->name('support.store');
        Route::get('/support/index', [SupportTicketController::class, 'destekindex'])->name('support.index');
        Route::post('/support/{id}/cevapla', [SupportTicketController::class, 'cevapla'])->name('support.cevapla');
        Route::delete('/support/{id}/sil', [SupportTicketController::class, 'delete'])->name('support.sil');
    });

    // Admin paneli
    Route::prefix('admin')->group(function () {

        Route::view('/panel', 'admin.panel')->name('admin.panel');

        // Etkinlik yönetimi
        Route::get('/etkinlikler', [AdminController::class, 'etkinlikView'])->name('admin.etkinlikler');
        Route::post('/etkinlik/ekle', [AdminController::class, 'addEvent'])->name('admin.etkinlik.ekle');
        Route::delete('/etkinlik/{id}', [AdminController::class, 'deleteEvent'])->name('admin.etkinlik.delete');
        Route::get('/etkinlik/edit/{id}', [AdminController::class, 'editEventshow'])->name('admin.etkinlik.showedit');
        Route::post('/etkinlik/update/{id}', [AdminController::class, 'editEventStore'])->name('admin.etkinlik.store');


        // Kullanıcı yönetimi
        Route::get('/kullanici_yonetim', [AdminController::class, 'userView'])->name('admin.kullanicilar');
        Route::get('/kullanici_duzenle/{id}', [AdminController::class, 'edit'])->name('admin.kullanici_duzenle');
        Route::post('/kullanici_guncelle/{id}', [AdminController::class, 'userUpdate'])->name('admin.kullanici_guncelle');
        Route::delete('/kullanici_sil/{id}', [AdminController::class, 'userDelete'])->name('admin.kullanici_sil');

        // Bilet yönetimi
        Route::get('/bilet_yonetim', [AdminController::class, 'ticketView'])->name('admin.biletler');
        Route::get('/biletler/pdf/{bilet_kodu}', [AdminController::class, 'showTicketPdf'])->name('admin.bilet.pdf');
        Route::post('/admin/tum-biletlerikullanıldı-yap', [AdminController::class, 'usedYap'])->name('admin.biletleri.used_yap');
        Route::post('/biletler/{id}/kullan', [AdminController::class, 'ticketUsed'])->name('admin.ticket.used');
        Route::delete('/biletler/{id}/sil', [AdminController::class, 'ticketDelete'])->name('admin.ticket.delete');

        // Duyuru yönetimi
        Route::get('/duyuru-olustur', [AnnouncementController::class, 'index'])->name('duyuru.index');
        Route::post('/duyuru/ekle', [AnnouncementController::class, 'addAnnouncement'])->name('duyuru.ekle');
        Route::delete('/duyuru/{id}/sil', [AnnouncementController::class, 'deleteAnnouncement'])->name('duyuru.sil');


        Route::get('/yorumlar', [YorumController::class, 'index'])->name('yorumlar.index');
        Route::delete('/yorumlar/{id}/sil', [YorumController::class, 'delete'])->name('yorumlar.delete');
        Route::post('/yorumlar/{id}/onayla', [YorumController::class, 'onayla'])->name('yorumlar.onayla');
    });
});
