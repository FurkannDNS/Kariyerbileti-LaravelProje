<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('ad', 50);
            $table->string('soyad', 50);
            $table->string('email', 100)->unique();
            $table->string('telefon', 15)->nullable();
            $table->enum('tip', ['admin', 'standart'])->default('standart');
            $table->enum('rol', ['organizatör', 'katilimci'])->nullable();
            $table->date('dogum_tarihi');
            $table->string('password');
            $table->timestamp('kayit_tarihi')->useCurrent();
            $table->timestamps();
        });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
