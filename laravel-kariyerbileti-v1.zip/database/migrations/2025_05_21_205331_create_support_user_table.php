<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSupportUserTable extends Migration
{
    public function up()
    {
        Schema::create('support_user', function (Blueprint $table) {
            $table->id(); // primary key
            $table->unsignedBigInteger('kullanici_id'); // kullanıcı id, foreign key olabilir
            $table->string('etkinlik_id'); // varchar, çünkü "KBPROG2025" gibi değerler olacak
            $table->string('kategori'); // destek kategorisi
            $table->text('destek_metni'); // destek mesajı
            $table->enum('status', ['beklemede', 'acik', 'kapali'])->default('beklemede');
            $table->timestamps(); // created_at ve updated_at

            // İstersen foreign key ekle (kullanici tablosu varsa)
            // $table->foreign('kullanici_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('support_user');
    }
}
