<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
    Schema::create('etkinlik_yorumlari', function (Blueprint $table) {
        $table->id();
        $table->foreignId('kullanici_id')->constrained('users')->onDelete('cascade');
        $table->string('etkinlik_kodu', 50);
        $table->text('yorum_metni');
        $table->enum('status', ['beklemede', 'onaylı', 'reddedilmiş'])->default('beklemede');
        $table->timestamps();

        $table->foreign('etkinlik_kodu')->references('etkinlik_kodu')->on('events')->onDelete('cascade')->onUpdate('cascade');
    });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('etkinlik_yorumlari');
    }
};
