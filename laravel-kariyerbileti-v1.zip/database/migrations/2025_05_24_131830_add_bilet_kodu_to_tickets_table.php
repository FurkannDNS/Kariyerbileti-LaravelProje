<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
        */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('etkinlik_kodu', 50);
            $table->enum('status', ['valid', 'used', 'cancelled'])->default('valid');
            $table->dateTime('purchase_date');
            $table->string('bilet_kodu')->unique(); // BİLET KODU EKLENDİ 🚀
            $table->timestamps();

            // İlişkilendirme örneği (opsiyonel)
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }



    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tickets', function (Blueprint $table) {
            //
        });
    }
};
