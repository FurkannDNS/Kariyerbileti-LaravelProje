<!DOCTYPE html>
<html lang="tr">

  <head>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>Bilet Detay Sayfası</title>


    <!-- Additional CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    <style>

    .left-image img {
        width: 100%;
        height: 20rem; /* Veya istediğin sabit yükseklik */
        object-fit: contain; /* Resmi kırparak alanı doldurur */
    }
    </style>

    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <x-preloader />
    
    <!-- ***** Preheader Start ***** -->
    <x-preheader />



    <!-- ***** Header Area Start ***** -->
    <x-header />




    <!-- ***** About Us Page ***** -->
    
    <div class="page-heading-shows-events">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Bilet Detayları</h2>
                    <span>Hep Katılmak İstediğin Etkinliğin Detayları Bu Sayfada!</span>
                </div>
            </div>
        </div>
    </div>

    <div class="ticket-details-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="left-image img-fluid w-100">
                        {{-- Etkinlik resmi --}}
                        <img src="{{asset( $event->image_path)}}" alt="etkinlik_resmi">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="right-content">
                        <h4>{{$event->title}}</h4>
                        <span>Etkinlik İçin Katılımcı Sınırı Yok<br>
                        Yaş Sınırı Bulunmamaktadır [BU KISIMLAR VERİ TABANINA EKLENMELİ- F]</span>
                        
                        <ul>
                            <li><i class="fa fa-clock-o"></i> {{$event->event_date}}</li>
                            <li><i class="fa fa-map-marker"></i>{{$event->location}}</li>
                        </ul>
                        <div class="quantity-content">
                            <div class="left-content">
                                <h6>Standard Bilet</h6>
                                <p style="font-family: Verdana;">{{$event->bilet_fiyati}} TL</p>
                            </div>
                            <div class="right-content">
                                <div class="quantity buttons_added">
                                    <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" class="input-text qty text" size="4" pattern="" inputmode="" disabled><input type="button" value="+" class="plus">
                                </div>
                                @if(Auth::check())
                                <div class="main-dark-button mt-3 text-center">
                                    <a href="{{ route('ticket-add-cart', ['code' => $event->etkinlik_kodu]) }}">Sepete Ekle</a>
                                    
                                    @if (session('success'))
                                        <!-- Modal -->
                                        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                                        <script>
                                            document.addEventListener("DOMContentLoaded", function() {
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Başarılı!',
                                                    text: '{{ session('success') }}',
                                                    confirmButtonText: 'Tamam'
                                                });
                                            });
                                        </script>
                                    @endif
                                @else
                                <div class="main-dark-button mt-3 text-center">
                                   <button type="button" class="btn btn-secondary" data-toggle="tooltip"
                                   data-placement="top" title="Lütfen Önce Giriş Yapın">Sepete Ekle</button>
                                </div>
                                @endif 
                                
                            </div>
                        </div>
                        <div class="total">
                            <span class="">Bir kullanıcı yalnızca 1 bilet satın alabilir*<br>
                                KariyerBİleti ,yalnızca aracı konumundadır. Bilet satışı harici herhangi bir yasal yükümlülüğü bulunmamaktadır.
                            </span>
                            <p class="muted text-capitalize fs-5">Buraya veritabanından detaylı açıklama kısmı gelecek-F</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    {{-- YORUMLAR BLOĞU --}}
    <section style="background-color:green;">
        <div class="container my-5 py-5 text-body">
            <h3 class="text-center mt-2 font-weight-bolder font-size-15 text-white">YORUMLAR</h3>

            <div class="row d-flex justify-content-center">
                <div class="col-md-11 col-lg-9 col-xl-7 col-sm-12 mt-4">

                    @forelse($event->yorumlar as $yorum)
                    <div class="d-flex flex-start mb-4">
                        <div class="col-1 d-flex flex-column align-items-center justify-content-center mt-0 bg-white" 
                            style="height: 50px; border-radius: 20px; width: 55px;">
                            <i class="fa-solid fa-user fa-2xl bg-body"></i>
                        </div>

                        <div class="card w-100">
                            <div class="card-body p-4">
                                <div>
                                    {{-- Kullanıcı adı (varsa), yoksa anonim --}}
                                    <h5>{{ $yorum->user->ad ?? 'Anonim' }}</h5>

                                    {{-- Tarih --}}
                                    <p class="small">{{ $yorum->created_at->diffForHumans() }}</p>

                                    {{-- Yorum Metni --}}
                                    <p>{{ $yorum->yorum_metni }}</p>

                                    {{-- Like & Dislike Butonları --}}
                                    <div class="d-flex justify-content-end align-items-center">
                                        <div class="d-flex align-items-center">
                                            <form method="POST" action="{{ route('yorum.oyla') }}" class="me-2">
                                                @csrf
                                                <input type="hidden" name="tur" value="like">
                                                <button class="btn btn-outline-success d-flex align-items-center gap-2 oyla-button" 
                                                        data-id="{{ $yorum->id }}" 
                                                        data-tur="like"
                                                        style="transition: 0.3s ease;">
                                                    <i class="fa-solid fa-thumbs-up"></i>
                                                    <span class="oy-sayisi">{{ $yorum->like_sayisi }}</span>
                                                </button>
                                            </form>

                                            <form method="POST" action="{{ route('yorum.oyla') }}" class="ms-3">
                                                @csrf
                                                <button class="btn btn-outline-danger d-flex align-items-center gap-2 oyla-button" 
                                                        data-id="{{ $yorum->id }}" 
                                                        data-tur="dislike"
                                                        style="transition: 0.3s ease;">
                                                    <i class="fa-solid fa-thumbs-down"></i>
                                                    <span class="oy-sayisi">{{ $yorum->dislike_sayisi }}</span>
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="alert alert-info text-center fs-5" role="alert" style="border-radius: 12px; background-color: #d1ecf1; color: #0c5460;">
                        Bu etkinlik için henüz yorum yapılmamış.
                    </div>
                    @endforelse

                </div>
            </div>

        </div>
        
        <p class="text-white fs-6 float-left" style="margin-left: 1rem;">
            *Profilim üzerinden etkinliği seçerek yorum yapabilirsiniz</p>
    </section>

       
    
    <!-- *** Footer *** -->
    <x-footer />
 
    

    <!-- ***** Scripts ***** -->
    <x-scripts />
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.oyla-button').forEach(button => {
                button.addEventListener('click', function (e) {
                    e.preventDefault();

                    const yorumId = this.dataset.id;
                    const tur = this.dataset.tur;
                    const btn = this;

                    fetch('/yorum-oyla', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        },
                        body: JSON.stringify({ yorum_id: yorumId, oy_turu: tur })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.like_sayisi !== undefined && data.dislike_sayisi !== undefined) {
                            // Yorum ID'ye göre doğru butonları bul
                            const likeBtn = document.querySelector(`.oyla-button[data-id="${yorumId}"][data-tur="like"]`);
                            const dislikeBtn = document.querySelector(`.oyla-button[data-id="${yorumId}"][data-tur="dislike"]`);

                            // Her iki sayıyı da güncelle
                            if (likeBtn) {
                                likeBtn.querySelector('.oy-sayisi').innerText = data.like_sayisi;
                            }
                            if (dislikeBtn) {
                                dislikeBtn.querySelector('.oy-sayisi').innerText = data.dislike_sayisi;
                            }
                        }

                        if (data.message) {
                            alert(data.message); // İstersen yerine toast koyabiliriz
                        }
                    })
                    .catch(err => {
                        console.error("Bir hata oluştu:", err);
                        alert("Bir hata oluştu. Lütfen tekrar deneyin.");
                    });
                });
            });
        });
    </script>


  </body>

</html>
