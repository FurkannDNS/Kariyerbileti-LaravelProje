<!-- Navbar -->

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm rounded-bottom-3" style="background-color: green;color: white;">
<div class="container">
    <a class="navbar-brand fw-bold " href="#">Yönetim Paneli</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
    aria-controls="navbarNav" aria-expanded="false" aria-label="Menüyü aç">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ms-auto">
        <li class="nav-item">
            <a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }} text-white" href="{{ route('admin.panel') }}">Ana Sayfa</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request()->routeIs('yorumlar.*') ? 'active' : '' }} text-white" href="{{ route('yorumlar.index') }}">Yorumlar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request()->routeIs('etkinlikler.*') ? 'active' : '' }} text-white" href="{{ route('admin.etkinlikler') }}">Etkinlikler</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request()->routeIs('kullanicilar.*') ? 'active' : '' }} text-white" href="{{ route('admin.kullanicilar') }}">Kullanıcılar</a>
        </li>
    </ul>
    </div>
</div>
</nav>

