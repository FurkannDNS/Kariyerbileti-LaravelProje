
     
<script src="{{ asset('assets/js/jquery-2.1.0.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.counterup.min.js') }}"></script>
<!-- Bootstrap -->
<script src="{{ asset('assets/js/popper.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<!-- Plugins -->
<script src="{{ asset('assets/js/scrollreveal.min.js') }}"></script>
<script src="{{ asset('assets/js/waypoints.min.js') }}"></script>

<script src="{{ asset('assets/js/imgfix.min.js') }}"></script> 
<script src="{{ asset('assets/js/mixitup.js') }}"></script> 
<script src="{{ asset('assets/js/accordions.js') }}"></script>
<script src="{{ asset('assets/js/owl-carousel.js') }}"></script>
<script src="{{ asset('assets/js/user-dropdown.js') }}"></script>
<script src="{{ asset('assets/js/user-info-alert.js') }}"></script>


<!-- Global Init -->
<!--<script src="{{ asset('assets/js/custom.js') }}"></script>-->
<script src="{{ asset('assets/js/custom.js') }}?v={{ time() }}"></script>

<script src="{{ asset('assets/js/payment.js') }}"></script>