<!-- Yeni Etkinlik Ekleme Formu -->
<div class="container card shadow-lg border-0 p-5 mt-5 rounded-4 bg-light">
    <div class="row">
        <div class="col-md-12">
        <div class="text-center mb-4">
            <h2 class="fw-bold display-5 text-primary">
            <i class="bi bi-calendar-plus"></i> Yeni Etkinlik Ekle
            </h2>
            <h5 class="text-secondary">Kayıt Sırasında Dİkkat Edilmesi Gerekenler</h5>
            <div class="mt-3">

            <p class="text-muted text-lg">Yeni bir etkinlik eklemek için aşağıdaki formu doldurun.</p>
            <p class="text-danger medium fst-italic">* Eklemek İstediğiniz Etkinlikiğin Bilgilerini Doğrulamadan Kayıt YAPMAYIN.</p>
            <p class="text-danger medium fst-italic">* Görselleri uygun formatta (.jpg, .png) yüklemeye özen gösterin.</p>
            <p class="text-danger small fst-italic">* Herhangi bir sorunda sistem yöneticisine başvurun.</p>
            <p class="text-danger small fst-italic">* Etkinlik Kodlarını Benzersiz Yapın!</p>
            </div>

        

        </div>

        <form action="{{ route('admin.etkinlik.ekle') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="mb-3">
            <label for="title" class="form-label fw-semibold">📌 Başlık</label>
            <input type="text" name="title" id="title" class="form-control shadow-sm" placeholder="Etkinlik başlığı girin" required>
            </div>

            <div class="mb-3">
            <label for="description" class="form-label fw-semibold">📝 Açıklama</label>
            <textarea name="description" id="description" class="form-control shadow-sm" rows="3" placeholder="Etkinlikle ilgili açıklama yazın..." required></textarea>
            </div>

            <div class="mb-3">
            <label for="image" class="form-label fw-semibold">🖼️ Görsel</label>
            <input type="file" name="image" id="image" class="form-control shadow-sm">
            </div>

            <div class="mb-3">
            <label for="event_date" class="form-label fw-semibold">📅 Etkinlik Tarihi</label>
            <input type="date" name="event_date" id="event_date" class="form-control shadow-sm" required>
            </div>

            <div class="mb-3">
            <label for="location" class="form-label fw-semibold">📍 Konum</label>
            <input type="text" name="location" id="location" class="form-control shadow-sm" placeholder="Etkinlik yeri" required>
            </div>

            <div class="mb-3">
            <label for="etkinlik_tipi" class="form-label fw-semibold">🎭 Etkinlik Tipi</label>
            <select name="etkinlik_tipi" id="etkinlik_tipi" class="form-select shadow-sm">
                <option value="online">Online</option>
                <option value="yüzyüze">Yüzyüze</option>
            <select>
            </div>

            <div class="mb-3">
            <label for="etkinlik_turu" class="form-label fw-semibold">🎨 Etkinlik Türü</label>
            <select name="etkinlik_turu" id="etkinlik_turu" class="form-select shadow-sm">
                <option value="konser">Konferans</option>
                <option value="seminer">Seminer</option>
                <option value="atölye">Atölye</option>
                <option value="online eğitim">Online Eğitim</option>
                <option value="diğer">Diğer</option>
            </select>
            </div>

            <div class="mb-3">
            <label for="bilet_fiyati" class="form-label fw-semibold">💰 Bilet Fiyatı</label>
            <input type="number" name="bilet_fiyati" id="bilet_fiyati" class="form-control shadow-sm" placeholder="₺" required>
            </div>

            <div class="mb-4">
            <label for="etkinlik_kodu" class="form-label fw-semibold">🔑 Etkinlik Kodu</label>
            <input type="text" name="etkinlik_kodu" id="etkinlik_kodu" class="form-control shadow-sm" placeholder="Etkinlik kodu girin" required>
            </div>

            <div class="text-center">
            <!-- Butonları kapsayan bir container div -->
            <div class="d-inline-block">
                <button type="submit" class="btn btn-md btn-success px-5 py-2 fw-bold">
                <i class="bi bi-check2-circle"></i> Etkinlik Ekle
                </button>
                <button type="reset" class="btn btn-sm btn-danger px-3 py-2 fw-bold ms-5">
                <i class="fa-solid fa-eraser" style="color: #ffffff;"></i> Formu Temizle
                </button>
            </div>
            </div>

        </form>
        </div>
    </div>
</div>