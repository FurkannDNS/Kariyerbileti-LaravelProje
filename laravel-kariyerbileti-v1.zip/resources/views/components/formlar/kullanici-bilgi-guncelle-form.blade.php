<!-- Modal  SAYFA ÜSTÜNE ÇIKAN PENCERE-->

<div class="modal fade" id="changeInfoModal" tabindex="-1" aria-labelledby="changeInfoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changeInfoModalLabel">Kullanıcı Bilgilerini Güncelle</h5>
                <button type="button" class="btn d-flex text-dark fs-5" data-bs-dismiss="modal" aria-label="Kapat">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="userInfoForm" method="POST" action="{{ route('user.update') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="firstName" class="form-label">Ad</label>
                        <input type="text" class="form-control" id="firstName" name="ad" value="{{ Auth::user()->ad }}" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="lastName" class="form-label">Soyad</label>
                        <input type="text" class="form-control" id="lastName" name="soyad" value="{{ Auth::user()->soyad }}" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">E-posta</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{ Auth::user()->email }}" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="telefon" class="form-label">Telefon</label>
                        <input type="text" class="form-control" id="telefon" name="telefon" value="{{ Auth::user()->telefon }}" maxlength="10">
                    </div>

                    
                    <div class="mb-3 text-center">
                        <button type="submit" class="btn btn-primary w-75">Güncelle</button>
                    </div>



                    <div class="mb-3 text-center">
                        <a href="#" id="showAlert" class="btn btn-link text-danger">Hesap Silme İşlemi</a>
                        <div id="alertBox" class="hide-alert alert-danger alert-dismissible fade show mt-3 text-center" style="display:none">
                            <p class="mb-0 text-center">
                                <strong>Dikkat:</strong> Hesabınızı silme işlemi <strong class="text-uppercase">kalıcıdır</strong> ve <strong class="text-uppercase">geri alınamaz</strong>.<br><br>
                                <strong>Bu işlemin ardından:</strong><br>
                                - Hesabınız bir daha geri getirilemez.<br>
                                - Aynı e-posta ile tekrar kayıt olsanız bile verilerinize erişemezsiniz.<br><br>
                                Emin değilseniz, hesabınızı geçici olarak devre dışı bırakmayı veya bizimle iletişime geçmeyi düşünebilirsiniz.
                            </p>
                        
                        </div>

                    </div>
                </form>
                <form class="text-center" action="{{ route('user.delete') }}" method="POST" onsubmit="return confirm('Hesabınızı silmek istediğinize emin misiniz? Bu işlem geri alınamaz!');">
                    @csrf
                    <button type="submit" class="btn btn-danger">
                        Hesabımı Sil
                    </button>
                </form>

            </div>
        </div>
    </div>
</div>
