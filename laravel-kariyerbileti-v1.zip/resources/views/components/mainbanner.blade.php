
<!-- ***** Anasayfadaki etkinlik sayaci ***** -->

<div class="main-banner">
    <div class="counter-content">
        <ul>
            <li>GUN<span id="days"></span></li>
            <li>SAAT<span id="hours"></span></li>
            <li>DAKIKA<span id="minutes"></span></li>
            <li>SANIYE<span id="seconds"></span></li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="main-content">
                    <div class="next-show">
                        <i class="fa fa-arrow-up"></i>
                        <span><a href="#icerik" style="color:white">Daha Fazlası</a></span>
                    </div>
                    
                    <h6>11 MAYIS PAZAR - HİTİT ÜNİVERSİTESİ [Ethem Erkoç Konferans Salonu] </h6>
                    <h2>TÜRKİYE BİLGİSAYAR MÜHENDİSLERİ ZİRVESİ 2025</h2>
                    <div class="main-white-button">
                        <a href="{{route('tickets')}}">BİLET AL</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ***** Main Banner Area End ***** -->