<div class="pre-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-sm-6">
                <span>Hey! Yeni Eklenen Etkinliklere Göz Attın Mı?..</span>
            </div>
            <div class="col-lg-6 col-sm-6">
                <div class="text-button"> <!-- ROUTE HATA VEREBİLİR-->
                <a href="{{ route('tickets') }}">GÜNCEL ETKİNLİKLER <i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>