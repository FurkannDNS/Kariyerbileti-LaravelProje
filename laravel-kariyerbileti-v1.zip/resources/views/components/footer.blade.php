<!-- *** Footer *** -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="address">
                    <h4>iletişim</h4>
                    <span>KariyerBileti<br>Kuzey Kampüsü, Çevre Yolu Blv., 19030<br>Merkez/Çorum<br>Telefon:+90 212 222 22 22<br>Email:info@kariyerbileti.com</span>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="links">
                    <h4>Hızlı Erişim</h4>
                    <ul>
                        <li><a href="{{route('main')}}">Anasayfa</a></li>
                        <li><a href="{{ route('about-us') }}">Hakkımızda</a></li>
                        <li><a href="#">Güncel Etkinlikler</a></li>
                        <li><a href="#">iletişim</a></li>
                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="hours">
                    <h4>Çalışma Saatleri</h4>
                    <ul>
                        <li>Pazartesi-Cuma: 10:00-18:00</li>
                        <li>Cumartesi-Pazar: 10:00-15:00</li>
                        <li>Tatiler: Kapalı</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="sub-footer">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-lg-3 text-lg-start text-center mb-3 mb-lg-0">
                            <div class="logo"><span>Kariyer<em>Bileti</em></span></div>
                        </div>
                        <div class="col-lg-3 text-lg-end text-center">
                            <div class="social-links">
                                <p class="social-label">Bize Buradan Ulaşın</p>
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item"><a href="https://twitter.com/" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                    <li class="list-inline-item"><a href="https://facebook.com/" target="_blank"><i class="fa-brands fa-facebook"></i></a></li>
                                    <li class="list-inline-item"><a href="https://www.linkedin.com/" target="_blank"><i class="fa-brands fa-linkedin"></i></a></li>
                                    <li class="list-inline-item"><a href="https://www.instagram.com/kendi_kullanici_adin/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</footer>