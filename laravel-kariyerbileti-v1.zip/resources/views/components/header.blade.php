<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <a href="{{ route('main') }}" class="logo">Kariyer<em>Bileti</em></a>
                    <ul class="nav">
                        <li>
                            <a href="{{ route('main') }}" class="{{ Route::currentRouteName() == 'main' ? 'active' : '' }}">
                                Ana Sayfa
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('about-us') }}" class="{{ Route::currentRouteName() == 'about-us' ? 'active' : '' }}">
                                Hakkımızda
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('tickets') }}" class="{{ Route::currentRouteName() == 'tickets' ? 'active' : '' }}">
                                Güncel Etkinlikler
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('show-cart') }}" class="{{ Route::currentRouteName() == 'show-cart' ? 'active' : '' }}">
                                SEPETİM
                            </a>
                        </li>

                        @if (Auth::check())
                            <div class="dropdown-container {{ Route::currentRouteName() == 'user.panel' ? 'active' : '' }}">
                                <button id="userDropdownToggle" class="dropdown-toggle">
                                    <span class="strong">{{ Auth::user()->ad }} {{ Auth::user()->soyad }}</span>

                                </button>

                                <ul id="userDropdownMenu" class="user-dropdown-menu">
                                    @if(Auth::user()->role === 'admin')
                                        <li><a class="d-flex flex-col justify-content-center align-items-center" href="{{ route('admin.panel') }}">Admin Paneli</a></li>
                                    @else
                                        <li><a class="d-flex flex-col justify-content-center align-items-center" href="{{ route('user.panel') }}">Profilim</a></li>
                                    @endif
                                        
                                    <li>
                                        <form action="/logout" method="POST">
                                            @csrf
                                            <button type="submit" class="btn text-center solid btn-outline-danger mt-2">Çıkış Yap</button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        @else
                            <li>
                                <div class="login-container">
                                    <button class="login-button">Giriş Yap / Kayıt Ol</button>
                                    <div class="dropdown">
                                        <a href="{{ route('oturum-ac') }}">Giriş Yap</a>
                                        <a href="{{ route('kayit-ol') }}" >Kayıt Ol</a>
                                    </div>
                                </div>
                            </li>
                        @endif
                    </ul>
                    <a class='menu-trigger'><span>Menu</span></a>
                </nav>
            </div>
        </div>
    </div>
</header>

<!--
Route::currentRouteName() Blade'de mevcut route adını döndürür. 
Böylece hangi sayfadaysan ona göre active class'ı eklenir.

Eğer bazı menü linkleri farklı route'lara sahip olabilir 
(örneğin, birden fazla URL tickets sayfasını açıyor olabilir), 
o zaman str_starts_with(Route::currentRouteName(), 'tickets.') 
gibi Blade içinde daha geniş kontroller de yapılabilir.

-->