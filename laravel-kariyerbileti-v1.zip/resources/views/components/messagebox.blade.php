@if (session('success'))
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center justify-content-between px-4 py-3 rounded shadow-sm" role="alert" style="border-left: 5px solid #28a745; background-color: #e6f9e6;">
        <div class="d-flex align-items-center">
            <i class="bi bi-check-circle-fill me-2" style="font-size: 1.5rem; color: #28a745;"></i>
            <div>
                <strong>Başarılı! </strong> {{ session('success') }}
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
    </div>

@endif

@if (session('error'))
    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center justify-content-between px-4 py-3 rounded shadow-sm" role="alert" style="border-left: 5px solid #dc3545; background-color: #ffecec;">
        <div class="d-flex align-items-center">
            <i class="bi bi-exclamation-circle-fill me-2" style="font-size: 1.5rem; color: #dc3545;"></i>
            <div>
                <strong>Hata! </strong> {{ session('error') }}
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
    </div>
@endif

@if (session('warning'))
    <div class="alert alert-warning alert-dismissible fade show d-flex align-items-center justify-content-between px-4 py-3 rounded shadow-sm" role="alert" style="border-left: 5px solid #ffc107; background-color: #fff8e1;">
        <div class="d-flex align-items-center">
            <i class="bi bi-exclamation-triangle-fill me-2" style="font-size: 1.5rem; color: #ffc107;"></i>
            <div>
                <strong>Uyarı! </strong> {{ session('warning') }}
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
    </div>

@endif
