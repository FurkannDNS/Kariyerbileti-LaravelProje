<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ödeme Sayfası</title>
  <!-- Additional CSS Files -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
    

  
  
</head>
<body>


    <!-- Sayfa Yükleniyor -->
    <x-preloader />


    <!-- *****(kucuk ust bar) ***** -->
    <div class="container-fluid bg-dark text-white py-3">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center float-left">
                  
                <a href="{{ route('user.panel') }}" class="btn btn-info btn-outline-success text-white me-2 mr-3">
                    <i class="fas fa-arrow-left me-2"></i>Geri</a>
            </div>
        </div>
    </div>




    <!-- Sayfa kapsayıcısı -->
    <div class="d-flex justify-content-center align-items-center vh-100 bg-light mt-5 mx-auto">

        <!-- Kart ve içerik -->
        <div class="card w-50 text-center shadow-sm" id="kart-blok">
            <div class="card-body">

                <h5 class="card-title mb-4">Siparişinizi Tamamlayın</h5>

                {{-- Kart Görünümü --}}
                <div class="d-flex justify-content-center text-white mb-4">
                    <div class="credit-card p-3 py-4  w-100">
                        <div class="d-flex justify-content-between align-items-center">
                            
                            <img id="card-logo" src="assets\images\Visa.svg" width="60" alt="Card Logo">
                        </div>

                        <div class="d-flex flex-wrap justify-content-center mt-4 font-weight-bold" id="card-number-display">
                            @for ($i = 0; $i < 16; $i++)
                                <span id="card-digit-{{ $i }}" class="mx-1">•</span>
                                @if (($i + 1) % 4 == 0)
                                    &nbsp;&nbsp;
                                @endif
                            @endfor
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <div class="d-flex flex-column">
                                <span class="common">Kart Sahibi</span>
                                <span id="card-holder">Ad Soyad</span>
                            </div>
                            <div class="d-flex flex-column align-items-center">
                                <span class="common">Son Kullanma Tarihi</span>
                                <span id="card-expiry">Ay/Yıl</span>
                            </div>
                            <div class="d-flex flex-column align-items-end">
                                <span class="common">CVV</span>
                                <span id="card-cvv">000</span>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- İŞLEM BAŞARI DURUMU --}}
                @if(session('success'))
                    <div class="alert alert-success z-50">{{ session('success') }}</div>
                @endif

                @if(session('fail'))
                    <div class="alert alert-danger z-50">{{ session('fail') }}</div>
                @endif

                {{-- Form Alanı --}}
                <form class="w-75 mx-auto" method="POST" action="{{ route('bakiye.yukle') }}">
                    @csrf
                    <div class="mb-3 text-start">
                        <label for="input-name" class="form-label">Kart Sahibi</label>
                        <input type="text" class="form-control" id="input-name" placeholder="Ad Soyad"  maxlength="50" required>
                    </div>

                    <div class="mb-3 text-start">
                        <label for="input-expiry" class="form-label">Son Kullanma Tarihi</label>
                        <input type="text" class="form-control" id="input-expiry" placeholder="AA/YY" maxlength="5"  required>
                    </div>

                    <div class="mb-3 text-start">
                        <label for="input-card-number" class="form-label">Kart Numaranız</label>
                        <input type="text" class="form-control" id="input-card-number" placeholder="XXXX XXXX XXXX XXXX" maxlength="19"  required>
                    </div>

                    <div class="mb-3 text-start">
                        <label for="input-cvv" class="form-label">CVV</label>
                        <input type="text" class="form-control" id="input-cvv" placeholder="999" maxlength="3"  required>
                    </div>

                    
                    <div class="btn-group w-100 d-flex flex-wrap gap-2 my-3" role="group" aria-label="Site Parası Seçimi">
                        <h6 class="title text-center mt-1 mb-1">AŞAĞIDA YÜKLEMEK İSTEDİĞİNİZ KARİYERPARA'YI SEÇEBİLİRSİNİZ!</h6>
                            @foreach([50, 100, 200, 500] as $tutar)
                                <input type="radio" class="btn-check" name="siteMoney" id="money{{ $tutar }}" value="{{ $tutar }}" autocomplete="off" {{ $tutar == 50 ? 'checked' : '' }}  required>
                                <label class="btn btn-outline-success flex-fill py-2" for="money{{ $tutar }}">{{ $tutar }} TL</label>
                            @endforeach
                    </div>


                    
                    <button type="submit" class="btn btn-success w-100 mt-3">Ödemeyi Tamamla</button>

                </form>

            </div>
        </div>
    </div>


    
    <!-- ***** Scripts ***** -->
    <x-scripts />


    
    
</body>
</html>
