<!DOCTYPE html>
<html lang="tr">
<head>
	
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" >
    
    <title>KariyerBileti - Sepetim</title>
    <!-- Additional CSS Files -->
     <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">


</head>
<body>
    
    
    <!-- ***** Preloader Start ***** -->
    <x-preloader />

    <!-- ***** Preheader Start ***** -->
    <x-preheader />

    <!-- ***** Header Area Start ***** -->
    <x-header />

    <x-messagebox />



    <main class="page">


        
        
        <section class="shopping-cart dark">
            <div class="container">
                <div class="block-heading">
                    <h2>SEPETİM</h2>
                    <p>Aşağıda Seçtiğiniz Etkinlikler Listelenmiştir. Biletler Tükenmeden Yerinizi Ayırtın!</p>
                </div>

                <div class="content">
                    <div class="row">
                        <div class="col-md-12 col-lg-8">
                            <div class="items">
                                @forelse ($cart as $id => $item)
                                <div class="product">
                                    <div class="row">
                                        <div class="col-md-4 mt-auto">
                                            <img class="img-fluid d-block mx-auto" src="{{ $item['image_path'] }}" alt="{{ $item['title'] }}">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="info">
                                                <div class="row">
                                                    <div class="col-md-9 product-name">
                                                        <a href="#">{{ $item['title'] }}</a>
                                                        <div class="product-info mt-2">
                                                            <div>Etkinlik Tarihi: <span>{{ $item['event_date'] }}</span></div>
                                                            <div>Etkinlik Yeri: <span>{{ $item['location'] ?? 'Belirtilmedi' }}</span></div>
                                                            <div>Etkinlik Tipi: <span>{{ $item['etkinlik_tipi'] ?? 'Belirtilmedi' }}</span></div>
                                                            <div>Etkinlik Türü: <span>{{ $item['etkinlik_turu'] ?? 'Belirtilmedi' }}</span></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 price d-flex flex-column">
                                                        <span>{{ number_format($item['bilet_fiyati'], 2) }} TL</span>
                                                        <form action="{{ route('cart-remove') }}" method="POST" class="mt-2">
                                                            @csrf
                                                            <input type="hidden" name="id" value="{{ $id }}">
                                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Bu etkinliği sepetten silmek istediğinizden emin misiniz?')">Kaldır</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @empty
                                <div class="alert alert-info">Sepetinizde ürün bulunmamaktadır.</div>
                                @endforelse
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-4">
                            <div class="summary">
                                <form action="{{ route('ticket.purchase') }}" method="POST">
                                    @csrf
                                    <h3>Sipariş Özeti</h3>

                                    @php
                                        $subtotal = 0;
                                        foreach($cart as $item) {
                                            $subtotal += $item['bilet_fiyati'] * $item['quantity'];
                                        }
                                        $discount = 0;
                                        $taxRate = 0.18;
                                        $tax = $subtotal * $taxRate;
                                        $grandTotal = $subtotal + $tax - $discount;
                                    @endphp

                                    <div class="summary-item">
                                        <span class="text">Ara Toplam</span>
                                        <span class="price">{{ number_format($subtotal, 2) }} ₺</span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="text">İndirim</span>
                                        <span class="price">{{ number_format($discount, 2) }} ₺</span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="text">KDV(%{{ $taxRate * 100 }})</span>
                                        <span class="price">{{ number_format($tax, 2) }} ₺</span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="text font-weight-bold">Toplam</span>
                                        <span class="price font-weight-bold">{{ number_format($grandTotal, 2) }} ₺</span>
                                    </div>

                                    <button type="submit" class="btn btn-success btn-lg btn-block">Öde</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

    </main>



    <!-- ***** Footer Start ***** -->
    <x-footer />
	
    
    <!-- Scripts -->
    <x-scripts />

</body>
</html>