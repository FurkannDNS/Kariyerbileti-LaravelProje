<!DOCTYPE html>
<html lang="tr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>KariyerBileti-Oturum Aç</title>



   <!-- Additional CSS Files -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">


    </head>
    
    <body>
    <!-- ***** Preloader(sayfa yukleyici) End ***** -->
    <x-preloader />

    <!-- ***** Preheader(kucuk ust bar) ***** -->
    <x-preheader />
    
    <!-- ***** Header kısmı ***** -->
    <x-header />

    


    <!-- ***** About Us Page ***** -->
    <div class="page-heading-rent-venue">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>GİRİŞ</h2>
                    <span>Hemen Giriş Yap, Keşfetmeye Başla!</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Girilen bilgiler doğru mu yanlış mı bilgisi veren kutucuklar-->
    <x-messagebox />

    <!-- Oturum Açma Formu -->
    <div class="giris-form">
        <div class="container">
            <div class="row">
            <div class="col-lg-12">
                <div class="heading-text">
                <h4>OTURUM AÇ</h4>
                </div>
                <div class="giris-form-kutusu">
                <form id="contact" action="{{ route('login') }}" method="POST">
                @csrf
                

                <div class="row justify-content-center">
                    <div class="col-md-6 col-sm-12">
                        <fieldset>
                            <input name="email" type="email" id="email" placeholder="E-Posta*" required>
                        </fieldset>
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-md-6 col-sm-12">
                        <fieldset>
                            <input name="password" type="password" maxlength="8" minlength="8" placeholder="8-Haneli Şifre*" required>
                        </fieldset>
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-md-6 col-sm-12 text-center">
                        <fieldset>
                            <button type="submit" id="form-submit" class="main-dark-button">Giriş Yap</button>
                        </fieldset>
                    </div>
                    
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-6 col-sm-12 text-center mt-3">
                        <fieldset>
                           <a href="{{ route('password.request') }}">Şifremi Unuttum</a>

                        </fieldset>
                    </div>
                    
                </div>
            </form>
                </div>
            </div>
            </div>
        </div>
        </div>



    <!-- *** Footer *** -->
    <x-footer />

    <!-- ***** Scripts ***** -->
     <x-scripts />

                                                    

  </body>
</html>