
<!DOCTYPE html>
<html lang="tr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>KariyerBileti - Güncel Etkinlikler</title>


    <!-- Additional CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

    


    </head>
    
    <body>
    
        <!-- ***** Preloader Start ***** -->
        <x-preloader />
        

        <!-- ***** Preheader Start ***** -->
        <x-preheader />

        <!-- ***** Header Area Start ***** -->
        <x-header />


        <div class="page-heading-shows-events">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Biletler Şimdi Satışta!</h2>
                        <span>Yaklaşan-Geçmiş Gösterileri ve Etkinlikleri İnceleyin, Hemen Biletinizi Alın!</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="tickets-page">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="search-box">
                        <form id="bilet-zaman-filtrele" method="GET" action="{{ route('tickets') }}">
                            <div class="row">   
                                <div class="col-lg-3">
                                    <select name="location" class="form-control">
                                        <option value="">Etkinlik Yeri</option>
                                        @foreach ($locations as $location)
                                            <option value="{{ $location }}">{{ $location }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-lg-2">
                                    <select name="etkinlik_turu" class="form-control">
                                        <option value="">Etkinlik Türü</option>
                                        <option value="aktivite">Aktivite</option>
                                        <option value="online eğitim">Online Eğitim</option>
                                        <option value="seminer">Seminer</option>
                                        <option value="konferans">Konferans</option>
                                    </select>
                                </div>
                                <div class="col-lg-2">
                                    <select name="fiyat" class="form-control">
                                        <option value="">Fiyat</option>
                                        <option value="0-100">0TL - 100TL</option>
                                        <option value="100-200">100TL - 200TL</option>
                                        <option value="200-300">200TL - 300TL</option>
                                    </select>
                                </div>

                                <div class="col-lg-2">
                                    <select name="tarih" class="form-control">
                                        <option value="">Tarih</option>
                                        <option value="asc">Önce En Yeni</option>
                                        <option value="desc">Önce En Eski</option>
                                    </select>

                                </div>

                                <div class="col-lg-3">
                                    <button type="submit" class="main-dark-button">Filtrele</button>
                                </div>
                            </div>
                        </form>

                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="heading">
                            <h2>Bilet Sayfası</h2>
                        </div>
                    </div>
                    
                    @foreach ($events as $event)
                    
              
                        <div class="col-lg-4">
                            <div class="ticket-item">
                                <div class="thumb">
                                    <img src="{{ asset($event->image_path) }}" alt="Etkinlik Görseli">

                                    <div class="price">
                                        <span>1 bilet<br>fiyat <em>{{ $event->bilet_fiyati }} TL</em></span>
                                    </div>
                                </div>
                                <div class="down-content">
                                    <span>{{ $event->description }}</span>
                                    <h4>{{ $event->title }}</h4>
                                    <ul>
                                        <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($event->event_date)->translatedFormat('d m Y') }}</li>
                                        <li><i class="fa fa-map-marker"></i>{{$event->location ?? 'KONUM YOK'}}</li>
                                    </ul>
                                    @if (!empty($event->etkinlik_kodu))
                                        <div class="main-dark-button">
                                            @if ($event->event_date < date('Y-m-d'))
                                                <a href="javascript:void(0);" class="disabled" style="pointer-events: none; opacity: 0.6;">
                                                    Etkinlik Sona Erdi
                                                </a>
                                            @else
                                                <a href="{{ route('ticket-details', ['code' => $event->etkinlik_kodu]) }}">
                                                    Bilet Satın Al
                                                </a>
                                            @endif
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach


                    
                    <div class="col-lg-12">
                        <div class="pagination">
                            <ul>
                                {{-- Etkinlik Verisi Buraya Gelmeli --}}
                                
                                {{-- Önceki Sayfa Linki --}}
                                <li>
                                    @if ($events->onFirstPage())
                                        <span>Önceki</span>
                                    @else
                                        <a href="{{ $events->previousPageUrl() }}">Önceki</a>
                                    @endif
                                </li>

                                {{-- Sayfa Numaraları --}}
                                @foreach ($events->getUrlRange(1, $events->lastPage()) as $page => $url)
                                    <li class="{{ $page == $events->currentPage() ? 'active' : '' }}">
                                        <a href="{{ $url }}">{{ $page }}</a>
                                    </li>
                                @endforeach

                                {{-- Sonraki Sayfa Linki --}}
                                <li>
                                    @if ($events->hasMorePages())
                                        <a href="{{ $events->nextPageUrl() }}">Sonraki</a>
                                    @else
                                        <span>Sonraki</span>
                                    @endif
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- *** Subscribe *** -->
        <x-subscribe />


        <!-- *** Footer *** -->
        <x-footer />
        
        

        <!-- ***** Scripts ***** -->
        <x-scripts />
        
    </body>
</html>