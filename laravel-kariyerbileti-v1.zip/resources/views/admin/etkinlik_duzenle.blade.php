<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Etkinlik Yönetimi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  


</head>


<body class="p-4">
  <a href="{{ route('admin.etkinlikler') }}" class="btn btn-secondary mb-3">← Geri Dön</a>
  <h2>Etkinlik Yönetimi</h2>
  <p>Burada etkinlikleri listeleyebilir, ekleyebilir veya düzenleyebilirsiniz.</p>

  <h1>Etkinlikler</h1>

  <x-messagebox />

 





<!-- 2. Accordion: Etkinlik Düzenleme -->

<div class="container card shadow-lg border-0 p-5 mt-5 rounded-4 bg-light">
  <div class="row">
    <div class="col-md-12">
      <div class="text-center mb-4">
        <h2 class="fw-bold display-5 text-primary">
          <i class="bi bi-pencil-square"></i> Etkinlik Düzenle
        </h2>
        <h5 class="text-secondary">Düzenleme Yaparken Dikkat Edilmesi Gerekenler</h5>
        <div class="mt-3">
          <p class="text-muted text-lg">Bir etkinliği düzenlemek için aşağıdaki formu güncelleyin.</p>
          <p class="text-danger medium fst-italic">* Etkinlik bilgilerini doğrulamadan kaydı güncellemeyin.</p>
          <p class="text-danger small fst-italic">* Görseli değiştirmek zorunda değilsiniz; sadece gerektiğinde yükleyin.</p>
        </div>
      </div>

      <form action="{{ route('admin.etkinlik.store',$editedEvent->id) }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
          <label for="title" class="form-label fw-semibold">📌 Yeni Başlık</label>
          <input type="text fw-bolder" name="title" id="title" class="form-control shadow-sm" value="{{$editedEvent->title ?? 'Başlık'}}" required>
        </div>

        <div class="mb-3">
          <label for="description" class="form-label fw-semibold">📝 Yeni Açıklama</label>
          <textarea name="description" id="description" class="form-control shadow-sm fw-semibold" rows="5" placeholder="{{ $editedEvent->description }}" required></textarea>
        </div>

        <div class="mb-3">
          <label for="image" class="form-label fw-semibold">🖼️ Yeni Görsel (İsteğe Bağlı)</label>
          <input type="file" name="image" id="image" class="form-control shadow-sm" value="{{ old('image', $editedEvent->image_path ?? '') }}">
          <img src="{{asset( $editedEvent->image_path)}}" alt="Eski Etkinlik Görseli" class="img-fluid mt-3" style="max-width: 10rem; height: 10rem;"> 
        </div>

        <div class="mb-3">
          <label for="event_date" class="form-label fw-semibold">📅 Yeni Etkinlik Tarihi</label>
          <input type="date" name="event_date" id="event_date" class="form-control shadow-sm"
            value="{{ old('event_date', $editedEvent->event_date ?? '') }}" required>
        </div>

        <div class="mb-3">
          <label for="location" class="form-label fw-semibold">📍 Yeni Konum</label>
          <input type="text" name="location" id="location" class="form-control shadow-sm" value="{{ $editedEvent->location ?? 'Veri Alınamadı' }}" required>
        </div>

        <div class="mb-3">
            <label for="etkinlik_tipi" class="form-label fw-semibold">🎭 Yeni Etkinlik Tipi</label>
            <select name="etkinlik_tipi" id="etkinlik_tipi" class="form-select shadow-sm">
                <option value="online" {{ (old('etkinlik_tipi', $editedEvent->etkinlik_tipi ?? '') == 'online') ? 'selected' : '' }}>Online</option>
                <option value="yüzyüze" {{ (old('etkinlik_tipi', $editedEvent->etkinlik_tipi ?? '') == 'yüzyüze') ? 'selected' : '' }}>Yüzyüze</option>
            </select>
        </div>


        <div class="mb-3">
            <label for="etkinlik_turu" class="form-label fw-semibold">🎨 Yeni Etkinlik Türü</label>
            <select name="etkinlik_turu" id="etkinlik_turu" class="form-select shadow-sm">
                <option value="konferans" {{ (old('etkinlik_turu', $editedEvent->etkinlik_turu ?? '') == 'konferans') ? 'selected' : '' }}>Konferans</option>
                <option value="seminer" {{ (old('etkinlik_turu', $editedEvent->etkinlik_turu ?? '') == 'seminer') ? 'selected' : '' }}>Seminer</option>
                <option value="atölye" {{ (old('etkinlik_turu', $editedEvent->etkinlik_turu ?? '') == 'atölye') ? 'selected' : '' }}>Atölye</option>
                <option value="online eğitim" {{ (old('etkinlik_turu', $editedEvent->etkinlik_turu ?? '') == 'online eğitim') ? 'selected' : '' }}>Online Eğitim</option>
                <option value="diğer" {{ (old('etkinlik_turu', $editedEvent->etkinlik_turu ?? '') == 'diğer') ? 'selected' : '' }}>Diğer</option>
            </select>
        </div>


        <div class="mb-3">
          <label for="bilet_fiyati" class="form-label fw-semibold">💰 Yeni Bilet Fiyatı</label>
          <input type="number" name="bilet_fiyati" id="bilet_fiyati" class="form-control shadow-sm" placeholder="₺" value="{{ $editedEvent->bilet_fiyati}}" required>
        </div>

        <div class="mb-4">
          <label for="etkinlik_kodu" class="form-label fw-semibold">🔑 Yeni Etkinlik Kodu</label>
          <input type="text" name="etkinlik_kodu" id="etkinlik_kodu" class="form-control shadow-sm" value="{{ $editedEvent->etkinlik_kodu }}" required>
        </div>

        <div class="text-center">
          <div class="d-inline-block">
            
            <button type="submit" class="btn btn-md btn-primary px-5 py-2 fw-bold">
            <i class="bi bi-save"></i> Değişiklikleri Kaydet
            </button>
            
            <button type="reset" class="btn btn-sm btn-secondary px-3 py-2 fw-bold ms-5">
              <i class="fa-solid fa-eraser" style="color: #ffffff;"></i> Formu Temizle
            </button>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>

<x-scripts />

</body>






</html>


