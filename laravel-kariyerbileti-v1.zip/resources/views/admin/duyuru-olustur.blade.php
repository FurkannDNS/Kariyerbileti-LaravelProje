<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Duyuru Yönetimi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a2d9b4f54e.js" crossorigin="anonymous"></script>
</head>
<body class="bg-light">
    <x-admin-comp.admin-navbar />


    <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
        <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
        ← Geri Dön
        </a>
    </div>



    <!-- Header -->
    <header class="bg-border-secondary-subtle py-4 mb-4 shadow-sm">
        <div class="container">
            <h1 class="display-5 fw-bold">
            <i class="fa-solid fa-compass fa-lg" style="color: #0a8014;"></i>
            Duyuru Yönetim Alt Paneli
            </h1>
            <p class="lead text-muted ms-3">
            Sistemdeki duyuruları buradan görüntüleyebilir, yönetebilirsiniz.
            </p>
        </div>
    </header>

    <x-messagebox />

    <div class="container p-3 mt-2">

        <h1 class="text-center mb-4">📢 Duyuru Yönetimi</h1>

        {{-- Yeni Duyuru Oluşturma Formu --}}
        <div class="card mb-5">
            <div class="card-header bg-success text-white">Yeni Duyuru Ekle</div>
            <div class="card-body">
                <form action="{{ route('duyuru.ekle') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="title" class="form-label">Başlık</label>
                        <input type="text" name="form_title" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="content" class="form-label">İçerik</label>
                        <textarea name="form_content" rows="4" class="form-control" required></textarea>
                    </div>

                    <div class="mb-3">
                       <p>*Duyuru Tarihi Otomatik Olarak "Bu Günün" Değerini Alacaktır.</p>
                        
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus me-1"></i> Ekle
                    </button>

                </form>
            </div>
        </div>

        {{-- Mevcut Duyurular --}}
        <div class="card">
            <div class="card-header bg-dark text-white">Mevcut Duyurular</div>
            <div class="card-body">
                @if($duyurular->isEmpty())
                    <p class="text-muted">Henüz duyuru yok.</p>
                @else
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 5%;">#</th>
                                <th style="width: 20%;">Başlık</th>
                                <th style="width: 50%;">İçerik</th>
                                <th style="width: 15%;">Tarih</th>
                                <th style="width: 10%;">İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($duyurular as $duyuru)
                                <tr>
                                    <td>{{ $loop->iteration}}</td>
                                    <td>{{ $duyuru->announcement_title }}</td>
                                    <td>{{ Str::limit($duyuru->announcement_content, 250) }}</td>
                                    <td>{{ $duyuru->created_at->format('d.m.Y H:i') }}</td>
                                    <td>
                                        <form action="{{ route('duyuru.sil', $duyuru->id) }}" method="POST" onsubmit="return confirm('Silmek istediğinizden emin misiniz?')">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash-alt me-1"></i> Sil
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

    </div>

</body>
</html>
