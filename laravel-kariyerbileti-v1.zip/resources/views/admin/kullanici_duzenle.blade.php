<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Kullanıcı Düzenle</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <x-admin-comp.admin-navbar />


  <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
    <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
      ← Geri Dön
    </a>
  </div>
  
  <h2 class="text-center">Kullanıcı Düzenle</h2>
  
  {{-- İşlem Mesajları --}}
  <x-messagebox />

  {{-- Kullanıcı Bilgileri --}}

  <x-preloader />
  

  <div class="card shadow-sm p-4 mt-4 w-75 align-content-center mx-auto">
  <h4 class="card-title mb-4">Kullanıcı Bilgilerini Güncelle</h4>

  <form action="{{ route('admin.kullanici_guncelle', $kullanici->id) }}" method="POST">
    @csrf

    <div class="mb-3">
      <label for="ad" class="form-label">Ad</label>
      <input type="text" class="form-control" id="ad" name="ad" value="{{ $kullanici->ad }}" required>
    </div>

    <div class="mb-3">
      <label for="soyad" class="form-label">Soyad</label>
      <input type="text" class="form-control" id="soyad" name="soyad" value="{{ $kullanici->soyad }}" required>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">E-mail</label>
      <input type="email" class="form-control" id="email" name="email" value="{{ $kullanici->email }}" required>
    </div>

    <div class="mb-3">
      <label for="telefon" class="form-label">Telefon</label>
      <input type="text" class="form-control" id="telefon" name="telefon" value="{{ $kullanici->telefon }}" required>
    </div>

    <div class="mb-3">
      <label for="dogum_tarihi" class="form-label">Doğum Tarihi</label>,
      <p class="fw-bold">{{ $kullanici->dogum_tarihi->format('d-m-Y') }}</p>
      <input type="date" class="form-control" id="dogum_tarihi" name="dogum_tarihi" 
      value="{{ old('dogum_tarihi', $kullanici->dogum_tarihi ?? '') }}" required>

    </div>

    <div class="mb-3">
      <label for="role" class="form-label">Rol</label>
      <select class="form-select" id="role" name="role" required>
        <option value="admin" {{ $kullanici->role === 'admin' ? 'selected' : '' }}>Admin</option>
        <option value="standart" {{ $kullanici->role === 'standart' ? 'selected' : '' }}>Standart</option>
      </select>
    </div>

    <div class="d-flex gap-3 mt-4 justify-content-center">
      {{-- Güncelle Butonu --}}
      <button type="submit" class="btn btn-primary w-50">Güncelle</button>

    </div>

  </form>
  <div class="d-flex gap-3 mt-4 justify-content-center">
      {{-- Sil Butonu --}}
    <form action="" method="POST">
      @csrf
      @method('DELETE')
      <button type="submit" class="btn btn-danger w-30">Sil</button>

    </form>
  </div>
</div>

  <x-scripts />

</body>
</html>
