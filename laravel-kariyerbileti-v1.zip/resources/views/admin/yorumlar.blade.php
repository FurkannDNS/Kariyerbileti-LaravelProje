<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Yorumlar</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

    <style>
        /* Modal için özel z-index ayarları */
        .modal {
            z-index: 9998 !important;
        }
        .modal-backdrop {
            z-index: 999 !important;
        }
        
        /* Dropdown menüler için */
        .dropdown-menu {
            z-index: 1031;
        }
        /* Hover efektleri */
        .hover-bg:hover {
            background-color: #f8f9fa;
        }
        /* Avatar stilleri */
        #avatar {
            width: 3rem;
            height: 3rem;
            font-weight: bold;
            font-size: 16px;
        }
        /* Modal açıldığında body scroll'unu engelle */
        body.modal-open {
            overflow: hidden !important;
        }
        /* Modal içerik stilleri */
        .modal-content {
            border: none;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }
        /* Responsive modal */
        @media (max-width: 576px) {
            .modal-dialog {
                margin: 1rem;
            }
        }

        /* Temayı yeşil yapacak özel Bootstrap renk override */
        .bg-primary {
            background-color:green !important; /* Bootstrap 5 yeşil */
        }
        .text-primary {
            color:green !important;
        }
        .btn-primary {
            background-color:green !important;
            border-color:green !important;
        }
        .btn-primary:hover, .btn-primary:focus {
            background-color: #157347 !important;
            border-color: #146c43 !important;
        }
        /* Badge renkleri yeşile uyumlu */
        .badge.bg-success {
            background-color: green !important;
        }
        .badge.bg-danger {
            background-color: #dc3545 !important; /* kırmızı zaten */
        }
        .badge.bg-warning.text-dark {
            background-color: #ffc107 !important;
            color: #212529 !important;
        }
    </style>
</head>
<body>
    
    <x-admin-comp.admin-navbar />


    <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
        <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
        ← Geri Dön
        </a>
    </div>

    <!--Mesaj kutusu-->
    <x-messagebox />


    <!-- Header -->
    <header class="bg-light py-4 mb-4 shadow-sm">
    <div class="container">
        <h1 class="display-5 fw-bold"><i class="fas fa-comments me-2 text-primary"></i>Yorum Yönetim Paneli</h1>
        <p class="lead text-muted">Sistemdeki kullanıcı yorumlarını buradan görüntüleyebilir, yönetebilirsiniz.</p>
    </div>
    </header>




    <div class="container p-4 mt-4">
        <div class="card border-0 shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-comments me-2"></i>Yorumlar</h5>
            </div>
            
            <div class="card-body p-0">
                @foreach ($yorums as $yorum)
                    <div class="yorum-card yorum-{{ $yorum->id }} border-bottom p-4 hover-bg">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="d-flex align-items-center">
                                <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" id="avatar">
                                    {{ strtoupper(mb_substr($yorum->user->ad ?? 'X', 0, 1)) }}
                                </div>
                                <div>
                                    <h6 class="mb-0 yorum-kullanici-adi">{{ $yorum->user->ad ?? 'Kullanıcı silinmiş' }}</h6>
                                    <small class="text-muted yorum-tarih">{{ $yorum->created_at->diffForHumans() }}</small>
                                </div>
                            </div>
                            
                            <div>
                                <span class="yorum-durum badge rounded-pill bg-{{ $yorum->status == 'onaylı' ? 'success' : ($yorum->status == 'reddedildi' ? 'danger' : 'warning text-dark') }}">
                                    {{ ucfirst($yorum->status) }}
                                </span>
                            </div>
                        </div>
                        
                        <div class="ms-5 ps-3">
                            <p class="mb-2 yorum-icerik">
                                {{ Str::limit($yorum->yorum_metni, 150) }}
                                @if(strlen($yorum->yorum_metni) > 150)
                                    <a href="#" class="yorum-detay-link text-decoration-none" data-bs-toggle="modal" data-bs-target="#yorum-onay-modal-{{ $yorum->id }}">
                                        <small>Devamını oku...</small>
                                    </a>
                                @endif
                            </p>
                            
                            <div class="d-flex gap-2 mt-3 yorum-butonu">
                                @if ( $yorum->status == 'onaylı')
                                    <button class="btn btn-success btn-sm rounded-pill px-3" disabled>
                                        <i class="fas fa-check me-1"></i>Onayla
                                    </button>
                                    
                                    <form action="{{ route('yorumlar.delete', $yorum->id) }}" method="POST" onsubmit="return confirm('Bu yorumu silmek istediğinize emin misiniz?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-outline-danger btn-sm rounded-pill px-3">
                                        <i class="fas fa-times me-1"></i> Reddet
                                    </button>
                                    
                                </form>
                                <span style="font-size:13px; color:rgb(73, 143, 212);">*Yorum Şu Anda Onaylı ve Yayında. Silme işlemi gerçekleştirebilirsiniz.</span>
                                
                                
                                @else
                                <form action="{{ route('yorumlar.onayla',$yorum->id) }}" method="POST">
                                    @csrf
                                    <button class="btn btn-success btn-sm rounded-pill px-3">
                                        <i class="fas fa-check me-1"></i> Onayla
                                    </button>
                                </form>
                                <form action="{{ route('yorumlar.delete', $yorum->id) }}" method="POST" onsubmit="return confirm('Bu yorumu silmek istediğinize emin misiniz?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-outline-danger btn-sm rounded-pill px-3">
                                        <i class="fas fa-times me-1"></i> Reddet
                                    </button>
                                </form>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="yorum-onay-modal-{{ $yorum->id }}" tabindex="-1" aria-labelledby="yorumModalLabel-{{ $yorum->id }}" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content yorum-onay-modal-content">
                                <div class="modal-header bg-light">
                                    <h6 class="modal-title" id="yorumModalLabel-{{ $yorum->id }}">
                                        <i class="fas fa-comment me-2"></i>{{ $yorum->user->ad.' '.$yorum->user->soyad ?? 'Kullanıcı silinmiş' }}'ın Yorumu
                                    </h6>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                                </div>
                                <div class="modal-body">

                                    <div class="yorum-detay p-3 bg-light rounded mb-3">
                                        {{ $yorum->yorum_metni }}
                                    </div>

                                    <div class="d-flex justify-content-between small text-muted">
                                        <span>Yorum ID: {{ $yorum->id }}</span>
                                        <span>{{ $yorum->created_at->format('d.m.Y H:i') }}</span>
                                    </div>

                                    <div class="d-flex justify-content-between small text-muted">
                                        <span>Etkinlik: {{ $yorum->event->title ?? 'VERİ YOK' }}</span>
                                        <span>Kullanıcı: {{ $yorum->kullanici_id ?? 'VERİ YOK' }}</span>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <form action="{{ route('yorumlar.onayla',$yorum->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        <button class="btn btn-success btn-sm">
                                            <i class="fas fa-check me-1"></i> Onayla
                                        </button>
                                    </form>
                                    <form action="{{ route('yorumlar.delete', $yorum->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-outline-danger btn-sm">
                                            <i class="fas fa-times me-1"></i> Reddet
                                        </button>
                                    </form>
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Kapat</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="card-footer bg-light">
                <small class="text-muted">Toplam {{ $yorums->count() }} yorum bulundu</small>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
