<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Destek Talepleri</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

  <style>
    .avatar-circle {
      width: 48px;
      height: 48px;
      font-size: 18px;
      font-weight: bold;
    }

    .destek-card:hover {
      background-color: #f8f9fa;
      transition: background-color 0.3s ease;
    }

    .destek-onay-modal-content {
      border-radius: 12px;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .destek-detay {
      background-color: #f1f1f1;
      border-left: 4px solid #0a8019;
      padding: 10px;
      font-style: italic;
    }

    .destek-durum {
      font-size: 0.75rem;
    }
  </style>
</head>
<body>
  <x-admin-comp.admin-navbar />

  <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
    <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
      ← Geri Dön
    </a>
  </div>

  <x-messagebox />

  <header class="bg-light py-4 mb-4 shadow-sm">
    <div class="container">
      <h1 class="display-5 fw-bold"><i class="fa-solid fa-headset me-2" style="color: #0a8019;"></i>Destek Yönetim Paneli</h1>
      <p class="lead text-muted">Sistemdeki destek taleplerini buradan görüntüleyebilir, yönetebilirsiniz.</p>
    </div>
  </header>

  <div class="container p-4 mt-4">
    <div class="card border-0 shadow">
      <div class="card-header bg-success text-white">
        <h5 class="mb-0"><i class="fas fa-comments me-2"></i>Talepler</h5>
      </div>

      <div class="card-body p-0">
        @foreach ($talepler as $talep)
          <div class="destek-card destek-{{ $talep->id }} border-bottom p-4 hover-bg">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div class="d-flex align-items-center">
                <div class="avatar-circle bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                  {{ strtoupper(mb_substr($talep->user->ad ?? 'X', 0, 1)) }}
                </div>
                <div>
                  <h6 class="mb-0 destek-kullanici-adi">
                    {{ optional($talep->user)->ad ?? 'Kullanıcı silinmiş' }} {{ optional($talep->user)->soyad ?? '' }}
                  </h6>
                  <small class="text-muted destek-tarih">{{ $talep->created_at->diffForHumans() }}</small>
                </div>
              </div>
              <div>
                <span class="destek-durum badge rounded-pill bg-{{ $talep->status == 'beklemede' ? 'secondary' : ($talep->status == 'reddedildi' ? 'danger' : 'warning text-dark') }}">
                  {{ ucfirst($talep->status) }}
                </span>
              </div>
            </div>

            <div class="ms-5 ps-3">
              <p class="mb-2 destek-icerik">
                {{ Str::limit($talep->destek_metni, 150) }}
                @if(strlen($talep->destek_metni) > 150)
                  <a href="#" class="destek-detay-link text-decoration-none" data-bs-toggle="modal" data-bs-target="#destek-modal-{{ $talep->id }}">
                    <small>Devamını oku...</small>
                  </a>
                
                  <hr class="my-4 mx-auto w-50" style="border-top: 5px solid  #080300;">


                @endif
              </p>

              <div class="d-flex gap-2 mt-3 destek-butonu">
                @if ( $talep->status == 'kapali')

                  <button class="btn btn-success btn-sm rounded-pill px-3" disabled>
                    <i class="fas fa-check me-1"></i>Destek Talebi Cevaplandı
                  </button>

                  <form action="{{ route('support.sil',$talep->id) }}" method="POST" onsubmit="return confirm('Bu talebi silmek istediğinize emin misiniz?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-outline-danger btn-sm rounded-pill px-3">
                      <i class="fas fa-times me-1"></i> Reddet
                    </button>
                  </form>

                  <span style="font-size:13px; color:rgb(73, 143, 212);">*Talep Şu Anda İşlemde. Silme işlemi gerçekleştirilebilir.</span>
                
                @else

                  <form action="{{ route('support.cevapla', $talep->id) }}" method="POST" class="w-100">
                    @csrf

                    <div class="d-flex justify-content-center align-items-center text-muted mb-3">
                      <textarea name="cevap_metni"
                          placeholder="Cevap Metni..."
                          class="form-control rounded-2 border shadow py-2"
                          rows="5"
                          required></textarea>
                    </div>

                    <div class="d-flex gap-2 justify-content-center">
                      <button type="submit" class="btn btn-success btn-sm rounded-pill px-3">
                        <i class="fas fa-check me-1"></i> Destek Talebini Cevapla
                      </button>
                  </form>

                  <form action="{{ route('support.sil',$talep->id) }}" method="POST" onsubmit="return confirm('Bu talebi silmek istediğinize emin misiniz?')" class="d-inline">
                      @csrf
                      @method('DELETE')
                      <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3">
                        <i class="fas fa-times me-1"></i> Reddet
                      </button>
                  </form>
                    </div>
                  

                @endif

              </div>
            </div>
          </div>




          <!--AÇILIR PENCERE-->
          <div class="modal fade" id="destek-modal-{{ $talep->id }}" tabindex="-1" aria-labelledby="destekModalLabel-{{ $talep->id }}" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content destek-onay-modal-content">
                <div class="modal-header bg-light">
                  <h6 class="modal-title" id="destekModalLabel-{{ $talep->id }}">
                    <i class="fas fa-comment me-2"></i>{{ $talep->user->ad.' '.$talep->user->soyad ?? 'Kullanıcı silinmiş' }}'in Talebi
                  </h6>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>

                <div class="modal-body">
                  <div class="destek-detay p-3 bg-light rounded mb-3">
                    {{ $talep->destek_metni }}
                  </div>
                  <div class="d-flex justify-content-between small text-muted">
                    <span>Talep ID: {{ $talep->id }}</span>
                    <span>{{ $talep->created_at->format('d.m.Y H:i') }}</span>
                  </div>
                  <div class="d-flex justify-content-between small text-muted">
                    <span>Etkinlik: {{ $talep->etkinlik_kodu ?? 'VERİ YOK' }}</span>
                    <span>Kullanıcı: {{ $talep->kullanici_id ?? 'VERİ YOK' }}</span>
                  </div>
                </div>



              <div class="modal-footer flex-column align-items-stretch gap-2">

                <form action="{{ route('support.cevapla', $talep->id) }}" method="POST">
                  @csrf
                    <div class="mb-2">
                      <textarea name="cevap_metni" placeholder="{{$talep->cevap_metni ?? 'Cevap Metni...' }}" 
                        class="form-control shadow-sm" rows="6"></textarea>
                    </div>

                  <button type="submit" class="btn btn-success w-100">
                    <i class="fas fa-check me-1"></i> Cevabı Gönder
                  </button>
                </form>

                <form action="{{ route('support.sil', $talep->id) }}" method="POST">
                  @csrf
                  @method('DELETE')
                  <button type="submit" class="btn btn-outline-danger w-100">
                    <i class="fas fa-times me-1"></i> Destek Talebini Sil
                  </button>
                </form>

                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">
                  Kapat
                </button>

              </div>


              </div>
            </div>
          </div>
        @endforeach
      </div>

      <div class="card-footer bg-light">
        <small class="text-muted">Toplam {{ $talepler->count() }} talep bulundu</small>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
