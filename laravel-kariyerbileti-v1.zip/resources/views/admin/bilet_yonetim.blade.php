<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Bilet Yönetimi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">


</head>
<body>

  <x-admin-comp.admin-navbar />


  <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
    <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
      ← Geri Dön
    </a>
    <form action="{{ route('admin.biletleri.used_yap') }}" method="POST" style="display:inline;">
      @csrf
      <button type="submit" class="btn btn-outline-secondary btn-light btn-sm">
        Geçmiş Biletleri Kullanılamaz Yap
      </button>
    </form>
  </div>

  <div class="container-md">
    <h2>Bilet Yönetimi</h2>
    <p>Buradan bilet işlemlerini gerçekleştirebilirsiniz.</p>
    <table class="table mt-5 min-vh-25">
      <thead>
          <tr>
              <th>Kullanıcı_ID</th>
              <th>KUllanıcı Adı</th>
              <th>Etkinlik Kodu</th>
              <th>Bilet Durumu</th>
              <th>Bilet Alım Tarihi</th>
              <th>İşlemler</th>

          </tr>
      </thead>

    <tbody>
      @if (Auth::check() && Auth::user()->role === 'admin')
        @foreach ($biletler as $bilet)
          <tr>
            <td>{{ $bilet->user_id ?? 'VERİ YOK' }}</td>
            <td>{{ optional($bilet->user)->ad ?? 'Ad' }} {{ optional($bilet->user)->soyad ?? 'Soyad' }}</td>
            <td>{{ $bilet->etkinlik_kodu ?? 'VERİ YOK' }}</td>
            <td>{{ $bilet->status ?? 'VERİ YOK' }}</td>
            <td>{{ $bilet->purchase_date ?? '-' }}</td>
            <td>


              <form action="{{ route('admin.ticket.used', $bilet->id) }}" method="POST" style="display:inline;">
                @csrf
                <button type="submit" class="btn btn-md" id="check-buton" onclick="return confirm('Bilet kullanıldı olarak işaretlensin mi?')">
                  <i class="fa-solid fa-circle-check"></i>
                </button>
              </form>
              
              
              <form action="{{ route('admin.ticket.delete', $bilet->id) }}" method="POST" style="display:inline;" >
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-md" id="x-buton" 
                onclick="return confirm('Bilet silinsin mi? Bu İşlemin Geri Dönüşü Yoktur!')">
                <i class="fa-solid fa-circle-xmark">
                </i></button>
              </form>

              
              <a  href="{{ route('admin.bilet.pdf', $bilet->bilet_kodu) }}" 
                class="btn btn-sm btn-info" 
                target="_blank">
                <i class="fas fa-file-pdf me-2"></i>
              </a>

            </td>
          </tr>
        @endforeach
      @else
        <tr>
          <td colspan="5" class="text-center text-danger">ADMİN OLARAK GİRİŞ YAPIN!</td>
        </tr>
      @endif
    </tbody>

    </table>
    <div class="container mt-5 mb-5">
      <div class="accordion" id="destekPaneli">
        
        <div class="accordion-item">
          <h2 class="accordion-header" id="destekOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#destekCollapseOne" aria-expanded="true" aria-controls="destekCollapseOne">
              Bilet Kullanımı Ne Anlama Geliyor?
            </button>
          </h2>
          <div id="destekCollapseOne" class="accordion-collapse collapse show" aria-labelledby="destekOne" data-bs-parent="#destekPaneli">
            <div class="accordion-body">
              <strong>"Bilet Kullanıldı" butonu</strong>, bir biletin etkinlikte kullanıldığını işaretler. Bu işlem sonrası bilet <code>used</code> durumuna geçer ve tekrar kullanılamaz.
              <p>"Geçmiş Biletleri kullanılamaz Yap" Butonu tüm veri tabanında tarihi geçmiş biletleri <strong class="text-danger text-uppercase">pasif
              </strong> hale getirir. Bu işlem, biletlerin tekrar kullanılmasını engeller ve veritabanında düzen sağlar.</p>
              <p>Bu işlemi yaparken dikkatli olun, çünkü bu işlem geri alınamaz. Biletler artık etkinliklerde kullanılamaz ve veritabanından silinmez.</p>
              </p>
            </div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header" id="destekTwo">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#destekCollapseTwo" aria-expanded="false" aria-controls="destekCollapseTwo">
              PDF İkonuna Tıklarsam Ne Olur?
            </button>
          </h2>
          <div id="destekCollapseTwo" class="accordion-collapse collapse" aria-labelledby="destekTwo" data-bs-parent="#destekPaneli">
            <div class="accordion-body">
              Bu ikon, biletin PDF formatındaki halini açar. PDF içerisinde kullanıcı bilgisi, etkinlik başlığı, tarih ve benzersiz bilet kodu yer alır. Tarayıcıda yeni sekmede açılır.
            </div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header" id="destekThree">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#destekCollapseThree" aria-expanded="false" aria-controls="destekCollapseThree">
              Bilet Silme Kalıcı mı?
            </button>
          </h2>
          <div id="destekCollapseThree" class="accordion-collapse collapse" aria-labelledby="destekThree" data-bs-parent="#destekPaneli">
            <div class="accordion-body">
              Evet. <strong>Sil</strong> butonuna bastığınızda, ilgili bilet veritabanından tamamen kaldırılır. Bu işlem geri alınamaz. Emin olmadan silmeyin!
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <x-scripts />

</body>
</html>
