<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Etkinlik Yönetimi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  


</head>


<body>


  <x-admin-comp.admin-navbar />
  
  <div class="container-sm d-flex flex-column flex-sm-row justify-content-center justify-content-sm-start gap-2 py-3">
    <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
      ← Geri Dön
    </a>

  </div>


    <!-- Header -->
  <header class="bg-border-secondary-subtle py-4 mb-4 shadow-sm">
    <div class="container">
        <h1 class="display-5 fw-bold">
          <i class="fa-solid fa-compass fa-lg" style="color: #0a8014;"></i>
          Etkinlik Yönetim Paneli
        </h1>
        <p class="lead text-muted ms-3">
          Sistemdeki etkinlikleri buradan görüntüleyebilir, yönetebilirsiniz.
        </p>
        <a href="{{ route('duyuru.index') }}" class="btn btn-outline-success btn-light btn-sm float-end py-1">
          Duyuru Ekle
        </a>
    </div>
  </header>


  <x-messagebox />

  <div class="container p-3 mt-2">
  <table class="table mt-3">
    <thead>
      <tr>
        <th>Başlık</th>
        <th>Etkinlik Tarihi</th>
        <th>Konum</th>
        <th>Fiyat</th>
        <th>İşlemler</th>
      </tr>
    </thead>
    <tbody>
      @foreach($etkinlikler as $etkinlik)
      <tr>
        <td>{{ $etkinlik->title }}</td>
        <td>{{ $etkinlik->event_date }}</td>
        <td>{{ $etkinlik->location }}</td>
        <td>{{ $etkinlik->bilet_fiyati }}₺</td>
        <td>
          <a href="{{ route('admin.etkinlik.showedit', $etkinlik->id) }}" class="btn btn-warning btn-sm py-1">Düzenle</a>
          <form action="{{ route('admin.etkinlik.delete', $etkinlik->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Etkinlik silinsin mi?')">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger btn-sm">Sil</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>




  <hr class="my-4 mx-auto w-50" >


  <div class="container mt-5">


    <div class="accordion mx-auto mt-2 py-1" id="accordionExample">
      <!--//* 
      AKORDİON İTEM 1
     *//-->
      <div class="accordion-item">

        <h2 class="accordion-header">
          <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
           <i class="fa-solid fa-circle-plus fa-beat me-2" style="color: #0a8005;"></i><span style="font-weight: 500;">Yeni Etkinlik Ekleme</span>
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <x-formlar.etkinlik-ekle-form />
          </div>
        </div>
        
      </div>






      <!--//* 
      AKORDİON İTEM 3
      *//-->
      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            <i class="fa-solid fa-circle-info fa-beat me-2" style="color: #0a8005;"></i><span style="font-weight: 500;">Destek Rehberi – Etkinlik Paneli</span>
          </button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <h5 class="fw-bold">🛠️ Yönetim Paneli Rehberi – Etkinlik İşlemleri</h5>
            <p>Bu yönetim ekranı sayesinde sistemdeki etkinlikleri tek bir noktadan <strong>ekleyebilir</strong>, <strong>görüntüleyebilir</strong>, <strong>düzenleyebilir</strong> ve gerekirse <strong>silebilirsiniz</strong>.</p>

            <hr>

            <h6>✅ Etkinlik Ekleme</h6>
            <ul>
              <li>Form alanlarını eksiksiz ve doğru şekilde doldurun.</li>
              <li><em>Etkinlik Tarihi</em>, <em>Tipi</em> ve <em>Türü</em> gibi alanlar standart veri girişi için zorunludur.</li>
              <li>Zorunlu alanlar boş bırakılırsa kayıt işlemi gerçekleşmez. Uyarılar gösterilir.</li>
            </ul>

            <h6>✏️ Etkinlik Düzenleme</h6>
            <ul>
              <li>“Düzenle” butonuyla ilgili etkinliği düzenleme formuna yönlendirilirsiniz.</li>
              <li>Form otomatik olarak etkinliğe ait bilgilerle dolar.</li>
              <li>Değişiklikleri yaptıktan sonra mutlaka <strong>kaydet</strong> butonuna basın.</li>
              <li>Eğer form boşsa, bir etkinlik seçmeden düzenleme sayfasına girmiş olabilirsiniz.</li>
            </ul>

            <h6>🗑️ Etkinlik Silme</h6>
            <ul>
              <li>Etkinlik kartlarının yanındaki “Sil” butonu ile işlem yapılır.</li>
              <li><strong>Geri alınamaz</strong> bir işlemdir. Silmeden önce emin olun.</li>
            </ul>

            <h6>🧩 Ekstra Notlar</h6>
            <ul>
              <li><strong>Etkinlik Tipi:</strong> Online / Yüzyüze — ileride filtreleme için kullanılabilir.</li>
              <li><strong>Etkinlik Türü:</strong> Konferans, Seminer, Atölye, Online Eğitim ve Diğer.</li>
              <li>Yeni türler eklemek için yazılım güncellemesi gerekebilir.</li>
              <li>Tarih alanı <code>&lt;input type="date"&gt;</code> kullanır; bazı tarayıcılarda görünüm farklı olabilir.</li>
            </ul>

            <h6>🔐 Güvenlik ve Tutarlılık</h6>
            <ul>
              <li>Bu sayfa yalnızca <strong>yetkili admin</strong> kullanıcıları için erişilebilirdir.</li>
              <li>Kayıtlı etkinlik verileri kullanıcıya açık alanda görüntülenebilir.</li>
              <li>Etkinlik adlarında ve açıklamalarda <strong>kişisel veya hassas bilgi</strong> paylaşmayın.</li>
            </ul>

            <p class="text-muted fst-italic mt-3">Herhangi bir sorunda sistem sorumlusuna başvurun.</p>
          </div>
        </div>
      </div>



    </div>
  </div>
  </div>


</body>



<x-scripts />



</html>


