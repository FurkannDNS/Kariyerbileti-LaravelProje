<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Admin Paneli</title>
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Additional CSS Files -->
  <!-- Font Awesome CDN -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
  

  
  
  
  <style>

  </style>
</head>


<body class="admin-body">

  
  <div class="admin-sidebar sidebar d-flex flex-column justify-content-start text-center min-vh-100 text-white">
    <h4 class="py-3 border-bottom">Admin Paneli</h4>

    <a href="{{ route('admin.etkinlikler') }}" class="sidebar-link text-white py-2">Etkinlik Yönetimi</a>
    <a href="{{ route('admin.kullanicilar') }}" class="sidebar-link text-white py-2">Kullanıcı Yönetimi</a>
    <a href="{{ route('admin.biletler') }}" class="sidebar-link text-white py-2">Bilet Yönetimi</a>
    <a href="{{ route('support.index') }}" class="sidebar-link text-white py-2">Destek Talepleri</a>
    <a href="{{route('yorumlar.index')}}"class="sidebar-link text-white py-2">Yorumlar</a>

    <form action="/logout" method="POST">
      @csrf
      <button type="submit" class="btn bg-danger btn-outline-light mt-3">Çıkış Yap</button>
    </form>
    <div class="mt-auto pt-1 border-top">
      <a href="{{ route('main') }}" class="admin-panel-logo float-none d-block text-white fw-bold text-center">
        Kariyer<em>Bileti</em>
      </a>
    </div>
  </div>

  {{-- HATA MESAJI KISIMLARI --}}
  @if(session('error'))
    <div class="alert alert-warning">
      {{ session('error') }}
    </div>
  @else
    <div class="alert alert-success">
      {{ session('success') }}
    </div>
  @endif

  
  
  <div class="content p-4">
    
    <div class="card">
      <div class="card-body row text-center">

        <!-- Kullanıcı -->
        <div class="col-lg-4 d-flex flex-column align-items-center justify-content-center">
          <i class="fa-solid fa-users fa-3x mb-3 text-primary"></i>
          <h5>Toplam Kullanıcı Sayısı</h5>
          <p class="fs-4">{{ \App\Models\User::count() }}</p>
        </div>

        <!-- Bilet -->
        <div class="col-lg-4 d-flex flex-column align-items-center justify-content-center">
          <i class="fa-solid fa-ticket fa-3x mb-3 text-success"></i>
          <h5>Toplam Bilet</h5>
          <p class="fs-4">{{ \App\Models\Ticket::count() }}</p>
        </div>

        <!-- Etkinlik -->
        <div class="col-lg-4 d-flex flex-column align-items-center justify-content-center">
          <i class="fa-solid fa-calendar-days fa-3x mb-3 text-warning"></i>
          <h5>Planlanmış Etkinlikler</h5>
          <p class="fs-4">{{ \App\Models\Event::count() }}</p>
        </div>
        <div class="card-body row text-end fs-6">
        <div class="col-lg-12 d-flex flex-column align-items-center justify-content-center">
          
            *Yukarıdaki Toplam kullanıcı sayısı admin dahil sayıyı göstermektedir.<br>
            
            **Bilet Sayısı sayfasında aktif biletler gösterilmektedir.
            ***
          
        </div>
      </div>

      </div>
    </div>
  </div>




  <script src="{{ asset('assets/js/jquery-2.1.0.min.js') }}"></script>

  <!-- Bootstrap -->
  <script src="{{ asset('assets/js/popper.js') }}"></script>
  <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>

  <!-- Plugins -->
  <script src="{{ asset('assets/js/scrollreveal.min.js') }}"></script>
  <script src="{{ asset('assets/js/waypoints.min.js') }}"></script>
  <script src="{{ asset('assets/js/jquery.counterup.min.js') }}"></script>
  <script src="{{ asset('assets/js/imgfix.min.js') }}"></script> 
  <script src="{{ asset('assets/js/mixitup.js') }}"></script> 
  <script src="{{ asset('assets/js/accordions.js') }}"></script>
  <script src="{{ asset('assets/js/owl-carousel.js') }}"></script>

  <!-- Global Init -->
  <script src="{{ asset('assets/js/custom.js') }}"></script>
</body>
</html>
