<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Kullanıcı Yönetimi</title>
  <!-- Additional CSS Files -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />



</head>

<body>
  <x-admin-comp.admin-navbar />
  
  <x-messagebox />
  
  <div class="contaier mt-2">
    <div class="container-fluid d-flex justify-content-between align-items-center h-100">
      <a href="{{ route('admin.panel') }}" class="btn btn-outline-success btn-light btn-sm">
        ← Geri Dön
      </a>
    </div>
  </div>


    <!-- Header -->
  <header class="bg-border-secondary-subtle py-4 mb-4 shadow-sm">
    <div class="container">
        <h1 class="display-5 fw-bold">
          <i class="fa-solid fa-users fa-lg" style="color: #0a8014;"></i>
          Kulllanıcı Yönetim Paneli
        </h1>
        <p class="lead text-muted ms-3">
          Sistemdeki kullanıcıları buradan görüntüleyebilir, yönetebilirsiniz.
        </p>
    </div>
  </header>




<div class="container p-3 mt-2">
    <table class="table mt-5">
      <thead>
          <tr>
              <th>Kullanıcı_ID</th>
              <th>Ad-Soyad</th>
              <th>E-mail</th>
              <th>Telefon</th>
              <th>Rol</th>
              <th>Doğum Tarihi</th>
              <th>İşlemler</th>

          </tr>
      </thead>

      <tbody>

        @foreach ($kullanicilar as $kullanici)
        <tr>
            <td>{{ $kullanici->id ??'VERİ YOK'}}</td>
            <td>{{ $kullanici->ad ??'VERİ YOK'}} {{ $kullanici->soyad ??'VERİ YOK' }}</td>
            <td>{{ $kullanici->email ??'VERİ YOK'}}</td>
            <td>{{ $kullanici->telefon ?? '-' }}</td>
            <td>{{ $kullanici->role ??'VERİ YOK'}}</td>
            <td>{{ $kullanici->dogum_tarihi ??'VERİ YOK'}}</td>
            @if ($kullanici->ad ==='admin')
              <td>
                <button class="btn btn-warning btn-sm" disabled>Düzenle</button>
                <button class="btn btn-danger btn-sm" disabled>Sil</button>
              </td>

            @else
              
              <td>
                <a class="btn btn-warning btn-sm" href="{{ route('admin.kullanici_duzenle', $kullanici->id) }}" style="display: inline;">Düzenle</a>

    
                <form action="{{ route('admin.kullanici_sil', $kullanici->id) }}" method="POST" style="display:inline;">
                  @csrf
                  @method('DELETE')
                  <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Kullanıcı sistemden silinsin mi?')">Sil</button>
                </form>
              </td>
            
            
            @endif
            
        </tr>
        @endforeach
        
          
      </tbody>
    </table>
  </div>














  <script src="{{ asset('assets/js/jquery-2.1.0.min.js') }}"></script>
  <script src="{{ asset('assets/js/jquery.counterup.min.js') }}"></script>
  <!-- Bootstrap -->
  <script src="{{ asset('assets/js/popper.js') }}"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>

  <!-- Plugins -->
  <script src="{{ asset('assets/js/scrollreveal.min.js') }}"></script>
  <script src="{{ asset('assets/js/waypoints.min.js') }}"></script>
  
  <script src="{{ asset('assets/js/imgfix.min.js') }}"></script> 
  <script src="{{ asset('assets/js/mixitup.js') }}"></script> 
  <script src="{{ asset('assets/js/accordions.js') }}"></script>
  <script src="{{ asset('assets/js/owl-carousel.js') }}"></script>
  <script src="{{ asset('assets/js/user-dropdown.js') }}"></script>
</body>
</html>
