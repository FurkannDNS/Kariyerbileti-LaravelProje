<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Bilet Bilgileri</title>
    <style>
        @page {
            size: A4;
            margin: 15mm 15mm 15mm 15mm;
        }

        body {
            font-family: 'DejaVu Sans', sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact; /* renkleri doğru yazdırmak için */
        }

        #bilet-pdf-container {
            width: 190mm;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            border: none;
            padding-bottom: 10mm;
        }

        #bilet-pdf-header {
            background: linear-gradient(90deg, #2e7d32 0%, #43a047 100%);
            color: #fff;
            text-align: center;
            padding: 25px 20px 35px 20px;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        #bilet-pdf-logo {
            height: 80px;
            margin-bottom: 15px;
            filter: drop-shadow(1px 1px 1px rgba(0,0,0,0.3));
        }

        #bilet-pdf-event-title {
            font-size: 28px;
            font-weight: 900;
            margin-bottom: 5px;
            letter-spacing: 1.2px;
        }

        #bilet-pdf-subtitle {
            font-size: 16px;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: 600;
            opacity: 0.85;
        }

        #bilet-pdf-body {
            padding: 30px 25px 25px 25px;
        }

        .bilet-pdf-info-row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 25px;
            justify-content: space-between;
        }

        .bilet-pdf-info-item {
            flex: 1 1 45%;
            background: #e9f0ec;
            border-left: 6px solid #388e3c;
            border-radius: 10px;
            padding: 20px 15px;
            box-shadow: 0 2px 8px rgba(56, 142, 60, 0.1);
            text-align: center;
            transition: background 0.3s ease;
        }

        .bilet-pdf-info-item:hover {
            background: #d7ead7;
        }

        .bilet-pdf-info-label {
            font-size: 16px;
            font-weight: 800;
            color: #2e7d32;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1.1px;
        }

        .bilet-pdf-info-value {
            font-size: 20px;
            font-weight: 700;
            color: #2b2b2b;
            word-wrap: break-word;
        }

        #bilet-pdf-info-item-full {
            width: 100%;
            background-color: #4caf50;
            color: #fff;
            padding: 20px 0;
            border-radius: 15px;
            text-align: center;
            font-size: 22px;
            font-weight: 900;
            box-shadow: inset 0 0 12px rgba(0,0,0,0.1);
            letter-spacing: 1.5px;
            user-select: all;
            margin-bottom: 20px;
        }

        #bilet-pdf-barcode-section {
            text-align: center;
            margin-top: 10px;
        }

        #bilet-pdf-barcode-lines {
            margin-bottom: 15px;
            height: 50px;
            user-select: none;
        }

        .bilet-pdf-barcode-line {
            display: inline-block;
            background-color: #222;
            margin: 0 1.5px;
            vertical-align: bottom;
            border-radius: 2px;
        }

        .bilet-pdf-line1 { width: 4px; height: 45px; }
        .bilet-pdf-line2 { width: 3px; height: 32px; }
        .bilet-pdf-line3 { width: 5px; height: 50px; }
        .bilet-pdf-line4 { width: 3px; height: 25px; }
        .bilet-pdf-line5 { width: 4px; height: 47px; }
        .bilet-pdf-line6 { width: 3px; height: 38px; }
        .bilet-pdf-line7 { width: 5px; height: 45px; }
        .bilet-pdf-line8 { width: 3px; height: 32px; }
        .bilet-pdf-line9 { width: 4px; height: 50px; }
        .bilet-pdf-line10 { width: 3px; height: 28px; }
        .bilet-pdf-line11 { width: 5px; height: 48px; }
        .bilet-pdf-line12 { width: 3px; height: 36px; }
        .bilet-pdf-line13 { width: 4px; height: 45px; }
        .bilet-pdf-line14 { width: 3px; height: 30px; }
        .bilet-pdf-line15 { width: 5px; height: 49px; }

        #bilet-pdf-barcode-text {
            font-size: 14px;
            letter-spacing: 2px;
            color: #222;
            font-family: monospace;
        }

        #bilet-pdf-rules-section {
            background: #e8f5e9;
            padding: 20px 25px;
            border-left: 6px solid #66bb6a;
            margin: 25px 25px 30px 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(102, 187, 106, 0.25);
        }

        .bilet-pdf-rules-title {
            font-size: 18px;
            font-weight: 900;
            margin-bottom: 15px;
            color: #2e7d32;
            text-transform: uppercase;
            letter-spacing: 1.2px;
        }

        .bilet-pdf-rules-list {
            margin: 0;
            padding-left: 1.8rem;
            color: #2e7d32;
            font-size: 15px;
            line-height: 1.6;
            font-weight: 600;
        }

        #bilet-pdf-footer {
            background: #fafafa;
            padding: 15px 20px;
            text-align: center;
            border-top: 1px dashed #a5d6a7;
            font-size: 13px;
            color: #555;
            border-bottom-left-radius: 15px;
            border-bottom-right-radius: 15px;
            user-select: none;
        }

        #bilet-pdf-warning-icon {
            display: inline-block;
            width: 20px;
            height: 20px;
            background-color: #e53935;
            color: white;
            font-weight: 900;
            text-align: center;
            line-height: 20px;
            border-radius: 50%;
            margin-right: 8px;
            font-family: Arial, sans-serif;
            user-select: none;
        }
    </style>
</head>

<body>

<div id="bilet-pdf-container">
    <div id="bilet-pdf-header">
        @php
            $logoPath = public_path('assets/images/site_logo.jpg');
            $logoData = base64_encode(file_get_contents($logoPath));
        @endphp

        <img src="data:image/jpeg;base64,{{ $logoData }}" alt="Logo" id="bilet-pdf-logo">
        <div id="bilet-pdf-event-title">{{ $etkinlik_baslik }}</div>
        <div id="bilet-pdf-subtitle">Giriş Bileti</div>
    </div>

    <div id="bilet-pdf-body">
        <div class="bilet-pdf-info-row">
            <div class="bilet-pdf-info-item">
                <div class="bilet-pdf-info-label">Etkinlik Adı</div>
                <div class="bilet-pdf-info-value">{{ $etkinlik_baslik }}</div>
            </div>
            <div class="bilet-pdf-info-item">
                <div class="bilet-pdf-info-label">Katılımcı</div>
                <div class="bilet-pdf-info-value">{{ $katilimci }}</div>
            </div>
        </div>

        <div class="bilet-pdf-info-row">
            <div class="bilet-pdf-info-item">
                <div class="bilet-pdf-info-label">Tarih & Saat</div>
                <div class="bilet-pdf-info-value">{{ $etkinlik_tarihi }}</div>
            </div>
            <div class="bilet-pdf-info-item">
                <div class="bilet-pdf-info-label">Etkinlik Yeri</div>
                <div class="bilet-pdf-info-value">{{ $etkinlik_yeri }}</div>
            </div>
        </div>

        <div class="bilet-pdf-info-row">
            <div id="bilet-pdf-info-item-full">
                Bilet Kodunuz: {{ $bilet_kodu }}
            </div>
        </div>

        <div id="bilet-pdf-barcode-section">
            <div id="bilet-pdf-barcode-lines">
                @for ($i = 1; $i <= 15; $i++)
                    <span class="bilet-pdf-barcode-line bilet-pdf-line{{ $i }}"></span>
                @endfor
            </div>
            <div id="bilet-pdf-barcode-text">0001-{{ $bilet_kodu }}-22000</div>
        </div>
    </div>

    <div id="bilet-pdf-rules-section">
        <div class="bilet-pdf-rules-title">Etkinlik Kuralları</div>
        <ul class="bilet-pdf-rules-list">
            <li>Bilet yalnızca belirtilen katılımcı tarafından kullanılabilir.</li>
            <li>Etkinlik alanına girişte kimlik kontrolü yapılabilir.</li>
            <li>Etkinlik başlangıcından en az 30 dakika önce alanda olunuz.</li>
            <li>Organizatör, programda değişiklik yapma hakkını saklı tutar.</li>
            <li>Bilet iadesi veya değişikliği yapılmamaktadır.</li>
        </ul>
    </div>

    <div id="bilet-pdf-footer">
        <span id="bilet-pdf-warning-icon">!</span>
        <strong>Bu bilet sadece {{ $katilimci }} adına geçerlidir.</strong><br>
        Etkinlik saatinden 30 dakika önce girişte olunuz.<br>
        <small>Bilet Kesim Tarihi: {{ $olusturmaZamani ?? 'Bilgi Yok' }}</small>
    </div>
</div>

</body>
</html>
