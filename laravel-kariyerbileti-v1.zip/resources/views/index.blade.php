<!DOCTYPE html>
<html lang="tr">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Tooplate">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
        <title>KariyerBileti - Senin Kariyerin, Senin Maceran!</title>
        <!-- Additional CSS Files -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
        
  </head>
    
    <body class="main">
    <!-- ***** Preloader(sayfa yukleyici) End ***** -->
    <x-preloader />

    <!-- ***** Preheader(kucuk ust bar) ***** -->
    <x-preheader />
    
    <!-- ***** Header kısmı ***** -->
    <x-header />

    <!-- ***** etkinlik sayaci***** -->
    <x-mainbanner />   





    <!-- *** Owl Carousel Items ***-->
    <div class="show-events-carousel">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="owl-show-events owl-carousel">
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0008.jpg" alt=""></a>
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0009.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0010.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0011.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0012.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0013.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0014.jpg" alt=""></a> 
                        </div>
                        <div class="item">
                            <a href="#"><img src="assets/images/IMG-20250501-WA0015.jpg" alt=""></a> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <!-- *** Duyurular Carousel ***-->
    <div id="duyuruCarousel" class="carousel slide mt-4" data-bs-ride="carousel">
        <h5 class="text-center" style="font-weight: 700;font-size: 3rem;">📢 Duyurular</h5>
        <div class="carousel-inner">

            @foreach($announcements as $index => $duyuru)
                <div class="carousel-item @if($index === 0) active @endif">
                    <div class="card shadow-lg border-0 mx-auto my-4" style="max-width: 600px; background: linear-gradient(135deg, #f8f9fa, #ffffff);">
                        <div class="card-body p-4">
                            <h5 class="card-title text-primary fw-bold mb-3">
                                <i class="fas fa-bullhorn me-2 fa-beat text-danger"></i> {{ $duyuru->announcement_title }}
                            </h5>
                            <p class="card-text text-secondary" style="font-size: 1rem;">
                                {{ $duyuru->announcement_content }}
                            </p>
                            <div class="text-end">
                                <small class="text-muted">{{ $duyuru->created_at->diffForHumans() }}</small>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#duyuruCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon bg-body-secondary rounded-circle" aria-hidden="true"></span>
            <span class="visually-hidden">Önceki</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#duyuruCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon bg-dark-subtle rounded-circle" aria-hidden="true"></span>
            <span class="visually-hidden">Sonraki</span>
        </button>
    </div>


    <!-- *** Site Tanıtımı ***-->
    <div class="amazing-venues">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="left-content">
                        <h4>Geleceğine Yatırım Yap, KariyerBileti ile Fark Yarat!</h4>
                        <p class="fw-medium"> KariyerBileti, kariyerini ve kişisel gelişimini desteklemek için birbirinden değerli etkinlikler sunar.<br>
                            İşaret dili eğitimlerinden yazılım konferanslarına, hukuk ve iletişim alanındaki seminerlerden yaratıcı sanat atölyelerine kadar geniş bir yelpazede fırsatlar seni bekliyor.
                            İlgi alanına uygun etkinliklere katılarak bilgi birikimini artırabilir, yeteneklerini geliştirebilir ve profesyonel ağını genişletebilirsin.
                            <br>
                            <br>Öğrenmenin ve gelişmenin en kolay yolu burada!<br>
                            Yeni beceriler edinmek, alanında uzman isimlerden eğitimler almak ve kariyer yolculuğunda güçlü adımlar atmak artık çok daha ulaşılabilir.
                            KariyerBileti ile hem kişisel hem de mesleki hedeflerine daha hızlı ulaşabilir, geleceğini bugünden şekillendirebilirsin.
                            <br>
                            Haydi, fırsatları kaçırma!
                            Etkinlikleri keşfet, biletini kolayca al ve kendin için en doğru yatırımı yap! 
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="right-content"   style="margin-top: 80px;" >
                        <img src="assets/images/Kisisel-Gelisim-Egitimi.jpg" alt="Your Image" class="img-fluid">
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-lg-8">
                    <div class="left-content">
                    <h3><strong>KariyerBileti ile Geleceğine Yön Ver!</strong></h3>

                    <p>
                    KariyerBileti, sadece bir etkinlik platformu değil; aynı zamanda bireylerin kariyerlerini inşa etmelerine, kişisel gelişimlerini hızlandırmalarına ve potansiyellerini keşfetmelerine yardımcı olan bir yol arkadaşıdır. 
                    Türkiye'nin dört bir yanındaki üniversiteler, alanında öncü kurumlar ve uzman eğitmenlerle iş birliği yaparak; teknoloji, hukuk, iletişim, tasarım, finans, girişimcilik ve daha pek çok alanda yüz yüze veya çevrim içi etkinlikler düzenler. 
                    Platformumuz, hem öğrenciler hem de profesyoneller için çağın gerektirdiği yetkinlikleri kazandırmayı amaçlar.
                    </p>

                    <p>
                    Katıldığın her etkinlik, CV’ni güçlendirir, sana yeni kapılar açar ve kariyer hedeflerine bir adım daha yaklaştırır. 
                    Gelişen iş dünyasında fark yaratmak isteyen herkes için KariyerBileti; bilgiye, networke ve başarıya giden yolun anahtarıdır. 
                    Ayrıca kullanıcı dostu arayüzü sayesinde etkinliklere göz atmak, başvurmak ve bilet almak sadece birkaç tık uzağında!
                    </p>

                    <p><strong>KariyerBileti ile doğru yerde, doğru zamanda, doğru adımları at!</strong> 🚀</p>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="right-content mt-4">
                        <img src="{{ asset('assets/images/ana-sayfa-içerik-2.jpg') }}" alt="Your Image" class="img-fluid">

                    </div>

                </div>
            </div>
        </div>
    </div>


    <!-- *** Tavsiye Etlinlikleri ***-->
    <div class="venue-tickets">
        <div class="container-fluid">
            <div class="row">
                <div class="d-flex flex-col justify-content-center col-lg-12">
                    <div class="section-heading">
                        <h2>Tavsiye Ettiğimiz Etkinlikler</h2>
                    </div>
                </div>
            </div>



           <!-- Tüm 3 kart - Eşit metin uzunluklarıyla -->
            <div class="row">
                <!-- 1. Kart -->
                <div class="col-md-6 col-lg-4">
                    <div class="venue-item">
                        <div class="thumb">
                            <img src="{{ asset('storage/assets/etkinlik_foto/bilet-resim-5.jpg') }}" alt="">
                        </div>
                        <div class="down-content">
                            <div class="left-content">
                                <div class="main-white-button">
                                    <a href="#">Bilet Satın Al</a>
                                </div>
                            </div>
                            <div class="right-content">
                                <h4>Bahar Doğa Yürüyüşü</h4>
                                <p>Doğanın uyanışına tanıklık etmek ister misiniz? Bahar doğa yürüyüşümüzde mis gibi orman havası, rengârenk çiçekler ve kuş cıvıltıları eşliğinde huzur dolu bir gün sizi bekliyor. Sınırlı kontenjanla gerçekleşecek bu eşsiz deneyimi kaçırmayın!</p>
                                <ul>
                                    <li><i class="fa fa-sitemap"></i>250</li>
                                    <li><i class="fa fa-user"></i>500</li>
                                </ul>
                                <div class="price">
                                    <span>1 bilet<br>fiyat <em>50TL</em></span>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>

                <!-- 2. Kart -->
                <div class="col-md-6 col-lg-4">
                    <div class="venue-item">
                        <div class="thumb">
                            <img src="{{ asset('storage/assets/etkinlik_foto/bilet-resim-11.jpg') }}" alt="resim-item">
                        </div>  <!-- KAPANIŞ ETİKETİ DÜZELTİLDİ -->
                        <div class="down-content">
                            <div class="left-content">
                                <div class="main-white-button">
                                    <a href="#">Bilet Satın Al</a>
                                </div>
                            </div>
                            <div class="right-content">
                                <h4>İş Dünyasında Kadın Olmak</h4>
                                <p>İş dünyasında kadın olmanın zorluklarını ve fırsatlarını keşfedin. Kadın Liderler Konferansı'nda, güçlü kadınların ilham verici deneyimlerinden öğrenerek kendi liderlik yolculuğunuza yön verecek bilgiler edinin.</p>
                                <ul>
                                    <li><i class="fa fa-sitemap"></i>450</li>
                                    <li><i class="fa fa-user"></i>650</li>
                                </ul>
                                <div class="price">
                                    <span>1 bilet<br>fiyat <em>100TL</em></span>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>

                <!-- 3. Kart - METİN KISALTILDI -->
                <div class="col-md-6 col-lg-4">
                    <div class="venue-item">
                        <div class="thumb">
                            <img src="{{ asset('storage/assets/etkinlik_foto/bilet-resim-15.jpg') }}" alt="">
                        </div>
                        <div class="down-content">
                            <div class="left-content">
                                <div class="main-white-button">
                                    <a href="#">Bilet Satın Al</a>
                                </div>
                            </div>
                            <div class="right-content">
                                <h4>İşaret Dili Eğitimi</h4>
                                <p>İşaret dili, iletişimi engelleri aşarak daha ulaşılabilir hale getirir. Online İşaret Dili Eğitimi'nde, temel işaretleri öğrenerek işaret diliyle etkili iletişim kurma yeteneğinizi geliştirebilirsiniz.</p>
                                <ul>
                                    <li><i class="fa fa-sitemap"></i>450</li>
                                    <li><i class="fa fa-user"></i>750</li>
                                </ul>
                                <div class="price">
                                    <span>1 bilet<br>fiyat <em>200TL</em></span>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <!-- *** Daha fazlası***-->
    <div class="coming-events">
        <div class="left-button">
            <div class="main-white-button">
                <a href="{{ route('tickets') }}">Daha fazlası</a>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="#"><img src="assets/images/bilet-resim-5.jpg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="#"><h4>Bahar Doğa Yürüyüşü</h4></a>
                            <ul>
                                <li><i class="fa fa-clock-o"></i> 24 Mayıs 2025 | Cumartesi: 08:00-13:00</li>
                                <li><i class="fa fa-map-marker"></i> Çorum Hitit Yolu İbikçam Budaközü vadisi</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="event-details.html"><img src="assets/images/bilet-resim-11.jpg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="event-details.html"><h4>Kadın Liderler Konferansı </h4></a>
                            <ul>
                                <li><i class="fa fa-clock-o"></i> 29 Mayıs 2025 | Perşembe: 10:00-14:00</li>
                                <li><i class="fa fa-map-marker"></i> Hitit Üniversitesi Ethem Erkoç Konferans Salonu</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="event-details.html"><img src="assets/images/bilet-resim-15.jpg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="event-details.html"><h4>İşaret Dili Eğitimi</h4></a>
                            <ul>
                                <li><i class="fa fa-clock-o"></i> Pazartesi: 09:00-11:00</li>
                                <li><i class="fa fa-laptop"></i> Eğitim Platformu: Google Meet<Pre> </Pre></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ***** Subscribe ***** -->
    <x-subscribe />

    <!-- ***** Footer ***** --> 
    <x-footer />


    <!-- ***** Scripts ***** -->
    <x-scripts />

   

  </body>
</html>