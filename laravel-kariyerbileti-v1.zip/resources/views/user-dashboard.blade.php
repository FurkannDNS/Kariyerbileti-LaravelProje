<!DOCTYPE html>
<html lang="tr">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>KariyerBileti-Profilim</title>



   <!-- Additional CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">







</head>

<body >

    
    <!-- ***** Header Area Start ***** -->
    <x-header />

    {{-- İŞLEM MESAJLARI KISMI --}}
    <x-messagebox />



    <!-- KULLANCII BİLGİLERİNİ GÖSTEREN KUTUCUKLAR ve İSLEM PANELİ-->

    <div class="container" id="main-content">
        <div class="dashboard-header">
        @if(Auth::check())
            <h2>Hoş Geldiniz, {{ Auth::user()->ad }}</h2>
        @endif
            <p>Burada hesabınızla ilgili bilgileri görebilirsiniz.</p>
        </div>

        <!-- Kullanıcı-Kayıt Bilgileri islem paneli -->
        <div class="row g-4 align-items-stretch">
            <!-- Kullanıcı Bilgileri -->
            <div class="col-md-4 d-flex">
                <div class="card shadow-sm user-info-block-1 w-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3 text-primary">
                            <i class="fas fa-user-circle me-2"></i> Kullanıcı Bilgileri
                        </h5>
                        <p class="card-text text-dark">
                            <i class="fas fa-user me-2 text-muted"></i><strong>Ad:</strong> {{ Auth::user()->ad }}<br>
                            <i class="fas fa-user-tag me-2 text-muted"></i><strong>Soyad:</strong> {{ Auth::user()->soyad }}<br>
                            <i class="fas fa-envelope me-2 text-muted"></i><strong>E-posta:</strong> {{ Auth::user()->email }}<br>
                            <i class="fas fa-phone me-2 text-muted"></i><strong>Telefon:</strong> {{ Auth::user()->telefon ?? 'Bilgi yok' }}<br>
                            <i class="fas fa-user-shield me-2 text-muted"></i><strong>Rol:</strong> {{ Auth::user()->role }}<br>
                            <i class="fas fa-birthday-cake me-2 text-muted"></i><strong>Doğum Tarihi:</strong> {{ Auth::user()->dogum_tarihi->format('d M Y') }}
                        </p>
                    </div>
                </div>
            </div>

            <!-- Kayıt Bilgileri -->
            <div class="col-md-4 d-flex">
                <div class="card shadow-sm user-info-block-2 w-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3 text-success">
                            <i class="fas fa-calendar-alt me-2"></i> Kayıt Bilgileri
                        </h5>
                        <p class="card-text text-dark">
                            <i class="fas fa-user-plus me-2 text-muted"></i><strong>Kayıt Tarihi:</strong> {{ Auth::user()->created_at->format('d M Y H:i') }}<br>
                            <i class="fas fa-user-edit me-2 text-muted"></i><strong>Son Güncelleme:</strong> {{ Auth::user()->updated_at->format('d M Y H:i') }}<br>
                            <i class="fas fa-coins me-2 text-warning"></i><strong>KariyerPARA:</strong> {{ Auth::user()->bakiye }} TL
                        </p>
                    </div>
                </div>
            </div>

            <!-- İşlem Paneli -->
            <div class="col-md-4 d-flex">
                <div class="card shadow-sm user-info-block-3 w-100">
                    <div class="card-body">
                        <h5 class="card-title text-center text-info">
                            <i class="fa-solid fa-toolbox fa-lg" style="color: #FFD43B;"></i> İşlemler</h5>
                        <ul>
                            <li>
                                <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#changeInfoModal">
                                    Kullanıcı Bilgilerini Düzenle
                                </button>
                            </li>
                            <li>
                                <a href="#" class="btn btn-outline-primary">Şifre Değiştir</a>
                            </li>
                            <li>
                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-danger">Çıkış Yap</button>
                                </form>
                            </li>
                            <li>
                                <a href="{{ route('main') }}" class="btn btn-info">ANA SAYFA</a>
                            </li>
                            <li>
                                <a href="{{ route('payment') }}" class="btn btn-warning">KariyerPara Yükle</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>

    




    
    {{-- Kullanıcı Bilgilerini Güncelleme Modal --}}
    @if (Auth::check())
        <x-formlar.kullanici-bilgi-guncelle-form />

    @else
        <div class="container" id="change-info-form">
            <div class="row justify-content-center">
                <div class="col-lg-12">
    
                    <div class="card">
                        <span>KULLANICI BİLGİLERİNİZ ALINIRKEN BİR HATA OLUŞTU</span>
                    </div>
                </div>
            </div>
        </div>



    @endif

    {{-- KULLANICI GEÇMİŞ EtKİNLİKLERİNİ GÖSTER --}}
    
    <hr class="my-5 mx-auto w-50" >

    @if($user->tickets->isEmpty())
        <div class="alert alert-info text-center" style="height:100px" role="alert">
            <p class="mt-3 fs-4 font-bold" style="font-family: Arial">Henüz hiç biletin yok!</p>
        </div>
    @else
        <div class="container mt-4 py-3">
            <div class="row text-center mx-auto">
                <div class="col-md-12 py-2 text-center" style="background-color: green; border-radius:15px; color:white">
                    <h3 class="display-6 fs-3">TÜM ETKİNLİKLERİNİN BURADA </span></h3>
                </div>
            </div>
            
        </div>
                
        <div class="container mt-4">
            <div class="row g-4 justify-content-center" id="my-last-events">
                @foreach($user->tickets as $ticket)
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="card h-100">
                            @if ($ticket->event)
                                <img class="card-img-top" src="{{ asset($ticket->event->image_path) }}" alt="bilet_image">
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title">{{ $ticket->event->title ?? 'Veri Bulunamadı' }}</h5>
                                </div>
                                <div class="card-footer">
                                    <p class="card-text mb-2">
                                        <strong>Durum:</strong>
                                        @if ($ticket->event->event_date < date('Y-m-d'))
                                            <span class="text-muted">Etkinlik Sona Erdi</span>
                                            @if($ticket->status === 'used')
                                                <span class="badge bg-secondary">Kullanıldı</span>

                                            @elseif($ticket->status === 'valid')
                                                <span class="badge bg-success text-white">Geçerli</span>
                                            @elseif($ticket->status === 'cancelled')
                                                <span class="badge bg-danger">İptal Edildi</span>
                                            @else
                                                <span class="badge bg-warning text-dark">{{ $ticket->status }}</span>
                                            @endif
                                        @else
                                            @if($ticket->status === 'valid')
                                                <span class="badge bg-primary">Etkinlik Bekleniyor</span>



                                            @elseif($ticket->status === 'used')
                                                <span class="badge bg-secondary">Kullanıldı</span>
                                                <!-- Yorum Yap Butonu -->


                                            @elseif($ticket->status === 'cancelled')
                                                <span class="badge bg-danger">İptal Edildi</span>




                                            @else
                                                <span class="badge bg-warning text-dark">{{ $ticket->status }}</span>
                                            @endif
                                        @endif
                                    </p>
                                    <small class="text-muted">Satın alınma tarihi: {{ $ticket->purchase_date->format('d.m.Y H:i') }}</small>

                                    @if ($ticket->event->event_date < date('Y-m-d') || $ticket->status === 'used')
                                        <button type="button" class="btn btn-sm btn-success mt-2" data-bs-toggle="modal" data-bs-target="#yorumYapModal">
                                            Yorum Yap 📝
                                        </button>

                                    @elseif($ticket->status === 'valid')
                                        <a href="{{ route('ticket.pdf', ['bilet_kodu' => $ticket->bilet_kodu]) }}" target="_blank" class="btn btn-info text-white font-weight-normal mt-2">
                                            Biletimi Görüntüle
                                        </a>
                                    @endif

                                </div>
                            @else
                            
                                <img class="card-img-top" src="{{ asset('storage/assets/etkinlik_foto/default-image.jpg') }}" alt="Etkinlik bulunamadı">
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title text-danger">Etkinlik Sistemden Kaldırıldı</h5>
                                </div>
                                <div class="card-footer">
                                    <p class="card-text mb-2">
                                        <strong>Durum:</strong>
                                        <span class="badge bg-dark-subtle">Silindi</span>
                                    </p>
                                    <small class="text-muted">Satın alınma tarihi: {{ $ticket->purchase_date->format('d.m.Y H:i') }}</small>

                                </div>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <!--Yorum Yap Modal -->
        <div class="modal fade" id="yorumYapModal" tabindex="-1" aria-labelledby="yorumYapModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="yorumYapModalLabel">Yorum Yap</h5>
                        <button type="button" class="btn d-flex text-dark fs-5" data-bs-dismiss="modal" aria-label="Kapat">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ route('yorum.store') }}">
                            @csrf
                           <input type="hidden" name="etkinlik_kodu" id="yorumEtkinlikKodu" value="{{ Auth::user()->tickets->first()->etkinlik_kodu ?? '' }}">


                            <div class="mb-3">
                                <label for="yorum_metni" class="form-label">Yorumunuz</label>
                                <textarea class="form-control" id="yorum_metni" name="yorum_metni" rows="4" required minlength="3" placeholder="Etkinlik hakkındaki düşüncelerinizi paylaşın..."></textarea>
                            </div>

                            <div class="mb-3 text-center">
                                <button type="submit" class="btn btn-primary w-75">Gönder</button>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
                
    @endif





    
    
    
    <hr class="my-4 mx-auto w-50" >

    <!-- DESTEK TALEBİ FORMU -->
    <div class="container mt-5">
        <div class="row g-4 align-items-start">
            
            <!-- SOL: Destek Formu -->
            <div class="col-lg-7">
                <div class="card shadow-sm border-0 rounded-4 h-100">
                    <div class="card-body p-4 border border-2 border-success rounded-4">
                        <h4 class="mb-4 text-success fw-bold text-center">Destek Talebi Oluştur</h4>

                        <form action="{{ route('support.store') }}" method="POST">
                            @csrf

                            <!-- Kategori -->
                            <div class="mb-3">
                                <label for="kategori" class="form-label fw-semibold">Destek Kategorisi</label>
                                <select class="form-select border-success shadow-sm" id="kategori" name="kategori" required>
                                    <option value="" disabled selected>Kategori Seçin</option>
                                    <option value="GENEL">GENEL</option>
                                    <option value="BİLET SORUNU">BİLET SORUNU</option>
                                    <option value="TEKNİK DESTEK">TEKNİK DESTEK</option>
                                    <option value="MUHASEBE">MUHASEBE</option>
                                </select>
                            </div>

                            <!-- Etkinlik -->
                            <div class="mb-3">
                                <label for="etkinlik_kodu" class="form-label fw-semibold">Etkinlik Seçimi</label>
                                <select class="form-select border-success shadow-sm" id="etkinlik_kodu" name="etkinlik_kodu" required>
                                    <option value="" disabled selected>Etkinlik Seçin</option>
                                    <option value="KONUDIŞI">Destek(Talep Konusu "Etkinlik" Değil İse İşaretleyin)</option>
                                    @foreach ($user->tickets as $info)
                                        <option value="{{ $info->etkinlik_kodu }}">
                                            {{ $info->event->title ??'Veri Bulunamadı' }} — {{ $info->etkinlik_kodu }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- Mesaj -->
                            <div class="mb-3">
                                <label for="destek_metni" class="form-label fw-semibold text-success">Destek Talebiniz</label>
                                <textarea
                                    class="form-control border-success shadow-sm"
                                    id="destek_metni"
                                    name="destek_metni"
                                    rows="6"
                                    required
                                    placeholder="Lütfen sorununuzu detaylı şekilde açıklayın..."
                                ></textarea>
                                <small class="text-muted">Lütfen mümkün olduğunca fazla detay girin.</small>
                            </div>

                            <!-- Gönder -->
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-success btn-lg px-5 shadow-sm">
                                    Talebi Gönder
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- SAĞ: Bilgilendirme -->
            <div class="col-lg-5">
                <div class="card shadow-sm border-0 rounded-4 h-100">
                    <div class="card-body p-4">
                        <h3 class="text-success fw-bold">Bize Ulaşın</h3>
                        <div class="d-flex float-end align-content-around">
                        <img src="assets\images\technical-support-svgrepo-com.svg" class="img-fluid rounded-3 shadow-sm " alt="Destek Ekibi" style="height:100px">
                        </div>
                        <p class="text-muted">
                            Destek ekibimize ulaşmak için lütfen formu dikkatli bir şekilde doldurun.
                            Açıklayıcı bilgiler vermeniz çözüm sürecini hızlandıracaktır.
                        </p>

                        <div class="alert alert-info mt-5 small">
                            <ul class="mb-0">
                                <li><strong>Etkinlik:</strong> Doğru etkinliği seçtiğinizden emin olun.</li>
                                <li><strong>Mesaj:</strong> Sorununuzu detaylıca açıklayın.</li>
                                <li><strong>Süre:</strong> Ortalama yanıt süremiz 24 saattir.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                



            </div>

        </div>
    </div>

    <div class="container-md overflow-scroll mt-3 rounded-2 shadow-lg card">
        <div class="container py-4 card-body">
            <h3 class="mb-4">Destek Talepleriniz</h3>

            <div style="max-height: 350px; overflow-y: auto;">
                @if($user->destek->count())
                    <div class="accordion" id="destekAccordion">
                        @foreach ($user->destek as $index => $talep)
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading{{ $index }}">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse{{ $index }}" aria-expanded="false" aria-controls="collapse{{ $index }}">
                                        Kategori: {{ $talep->kategori }} - Durum: 
                                        <span class="badge ms-2 bg-{{ 
                                            $talep->status === 'kapali' ? 'secondary' : 
                                            ($talep->status === 'acik' ? 'success' : 'warning') 
                                        }}">
                                            {{ ucfirst($talep->status) }}
                                        </span>
                                    </button>
                                </h2>
                                <div id="collapse{{ $index }}" class="accordion-collapse collapse" aria-labelledby="heading{{ $index }}" data-bs-parent="#destekAccordion">
                                    <div class="accordion-body">
                                        <div class="mb-3 p-3 rounded-3 bg-light border border-primary" style="white-space: pre-wrap;">
                                            <strong>Gönderdiğiniz Mesaj:</strong><br>
                                            {{ $talep->destek_metni }}
                                        </div>

                                        @if ($talep->cevap_metni)
                                            <div class="mb-2 p-3 rounded-3 bg-success bg-opacity-10 border border-success" style="white-space: pre-wrap; color: #155724;">
                                                <strong>Admin Cevabı:</strong><br>
                                                {{ $talep->cevap_metni }}
                                            </div>
                                        @else
                                            <p class="mb-0 text-muted fst-italic">Henüz cevaplanmadı.</p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p class="text-muted">Henüz destek talebiniz yok.</p>
                @endif
            </div>
        </div>
    </div>


   
    <br><br>

    <!-- *** Footer *** -->
    <x-footer />

    <x-scripts />
    <script>
    if (window.history && window.history.pushState) {
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () {
            window.location.href = "{{ route('main') }}";
        };
    }
</script>                              
</body>
</html>
