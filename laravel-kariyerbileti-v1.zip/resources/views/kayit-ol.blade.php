<!DOCTYPE html>
<html lang="tr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>KariyerBileti-Kayıt Ol</title>


    <!-- Additional CSS Files -->
   <!-- Additional CSS Files -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/tooplate-artxibition.css') }}">


    </head>
    
    <body>
    
    <!-- Sayfa Yükleniyor -->
    <x-preloader />
    <!-- ***** Header kısmı ***** -->
    <x-preheader />
    
    <x-header />
    <!-- ***** Header kısmı ***** -->


    <!-- ***** About Us Page ***** -->
    <div class="page-heading-rent-venue">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>KAYIT OL</h2>
                    <span>AŞAĞIDAKİ FORMU DOLDURARAK ARAMIZA KATILABİLİRSİN!</span>
                </div>
            </div>
        </div>
    </div>


    <div class="kayit-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="heading-text">
                        <h4>KAYIT OL</h4>
                    </div>
                    <div class="kayit-form-kutusu">

                    <!--İŞLEM BAŞARILI İSE;-->
                    @if (session('success'))
                        <div class="alert alert-success text-center">
                            {{ session('success') }}
                        </div>
                    @endif

                    <!--İŞLEM BAŞARISIZ İSE;-->
                    @if (session('failure'))
                        <div class="alert alert-danger text-center">
                            {{ session('failure') }}
                        </div>
                    @endif      

                    <!--Herhangi bir hata alırsak-->
                    @if ($errors->any())
                        <div class="alert alert-danger text-center">
                            @foreach ($errors->all() as $error)
                                <div>{{ $error }}</div>
                            @endforeach
                        </div>
                    @endif


                    <form id="contact" action="{{ route('users.store') }}" method="POST">
                        
                        @csrf 
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <fieldset>
                                    <input name="ad" type="text" id="name" placeholder="Adınız" required>
                                </fieldset>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <fieldset>
                                    <input name="soyad" type="text" id="surname" placeholder="Soyadınız" required>
                                </fieldset>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <fieldset>
                                    <input name="email" type="email" id="email" placeholder="E-Posta*" required>
                                </fieldset>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <fieldset>
                                    <input name="telefon" type="text" id="phone-number" placeholder="Telefon Numarası*" maxlength="10"required>
                                </fieldset>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6">
                                <fieldset>
                                    <input name="password" type="password" maxlength="8" minlength="8" placeholder="8-Hanelisifre*" required>
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <fieldset>
                                    <input name="dogum_tarihi" type="date" id="date-requested-first" placeholder="Doğum Tarihi*" required>
                                </fieldset>
                            </div>

                            
                        </div>
                        <div class="row">
                            <div class="col-sm-12 d-flex justify-content-center align-items-center mt-0">
                                <fieldset class="text-center">
                    
                                    <select name="role" required>
                                        <option value="standart" selected>Standart</option>                                      
                                    </select>
                                </fieldset>

                            </div>
                        </div>

                        <div class="row">
                        <div class="col-md-12 col-sm-6 mt-3">
                                <fieldset>
                                    <button type="submit" id="form-submit" class="main-dark-button">Kayıt Ol</button>
                                </fieldset>
                            </div>

                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- *** Footer *** -->
    <x-footer />

    <!--scriptler-->
    <x-scripts />
                                                    

  </body>
</html>